package com.example.game

import androidx.compose.ui.graphics.Color
import com.example.data.GamePreferences
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.sin
import kotlin.random.Random

enum class GameStatus {
    MENU,
    RUNNING,
    PAUSED,
    GAME_OVER
}

data class PlayerVisualState(
    val laneX: Float, // -1.0f to 1.0f
    val jumpY: Float, // 0.0f to 1.5f
    val isSliding: Boolean,
    val slideProgress: Float, // 0f to 1f
    val runStepCycle: Float, // 0f to 1f (for leg/arm swing)
    val isInvincible: Boolean,
    val isShielded: Boolean,
    val isMagnetActive: Boolean,
    val isSpeedBoosting: Boolean,
    val isStumbling: Boolean,
    val tiltAngle: Float = 0f, // degrees of banking during dodge
    val squashX: Float = 1.0f,
    val squashY: Float = 1.0f
)

data class GameState(
    val status: GameStatus = GameStatus.MENU,
    val score: Int = 0,
    val distanceMeters: Float = 0f,
    val coinsThisRun: Int = 0,
    val gemsThisRun: Int = 0,
    val multiplier: Int = 1,
    val speed: Float = 14f, // meters per second
    val player: PlayerVisualState = PlayerVisualState(0f, 0f, false, 0f, 0f, false, false, false, false, false),
    val beastDistance: Float = 16f, // meters behind player
    val obstacles: List<Obstacle> = emptyList(),
    val collectibles: List<Collectible> = emptyList(),
    val activePowerUps: List<ActivePowerUp> = emptyList(),
    val particles: List<Particle> = emptyList(),
    val scorePopups: List<ScorePopup> = emptyList(),
    val torches: List<Torch> = emptyList(),
    val equippedCharacter: GameCharacter = CharacterCatalog.BASE_CHARACTER,
    val equippedCosmetic: CosmeticItem? = null,
    val deathReason: String = ""
)

class GameEngine(
    private val preferences: GamePreferences,
    private val onHapticFeedback: (type: String) -> Unit = {}
) {
    private val _gameState = MutableStateFlow(GameState())
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    private var targetLane = Lane.CENTER
    private var currentLaneX = 0f
    private var currentTiltAngle = 0f
    private var squashX = 1.0f
    private var squashY = 1.0f
    private var landingSquashTimer = 0f
    private var jumpVelocity = 0f
    private var currentJumpY = 0f
    private var isSliding = false
    private var slideTimer = 0f
    private var stumbleTimer = 0f

    private var runStepTimer = 0f
    private var speed = 14f
    private var distanceMeters = 0f
    private var score = 0
    private var coinsThisRun = 0
    private var gemsThisRun = 0
    private var streakMultiplier = 1
    private var streakCounter = 0

    private var beastDistance = 18f
    private var solarisUsedAegis = false

    private val obstacles = mutableListOf<Obstacle>()
    private val collectibles = mutableListOf<Collectible>()
    private val activePowerUps = mutableListOf<ActivePowerUp>()
    private val particles = mutableListOf<Particle>()
    private val scorePopups = mutableListOf<ScorePopup>()
    private val torches = mutableListOf<Torch>()

    private var nextObstacleZ = 25f
    private var nextTorchZ = 5f
    private var idCounter = 1L

    init {
        initTorches()
        refreshEquippedItems()
    }

    fun refreshEquippedItems() {
        val charId = preferences.equippedCharacterId.value
        val cosmeticId = preferences.equippedCosmeticId.value
        val char = CharacterCatalog.getById(charId)
        val cosmetic = CosmeticCatalog.getById(cosmeticId)
        _gameState.value = _gameState.value.copy(
            equippedCharacter = char,
            equippedCosmetic = cosmetic
        )
    }

    private fun initTorches() {
        torches.clear()
        for (i in 0..15) {
            val z = i * 8f
            torches.add(Torch(z = z, isLeft = true))
            torches.add(Torch(z = z, isLeft = false))
        }
    }

    fun startNewGame() {
        refreshEquippedItems()
        targetLane = Lane.CENTER
        currentLaneX = 0f
        currentTiltAngle = 0f
        squashX = 1.0f
        squashY = 1.0f
        landingSquashTimer = 0f
        jumpVelocity = 0f
        currentJumpY = 0f
        isSliding = false
        slideTimer = 0f
        stumbleTimer = 0f
        runStepTimer = 0f
        speed = 14f
        distanceMeters = 0f
        score = 0
        coinsThisRun = 0
        gemsThisRun = 0
        streakMultiplier = 1
        streakCounter = 0
        beastDistance = 18f
        solarisUsedAegis = false

        obstacles.clear()
        collectibles.clear()
        activePowerUps.clear()
        particles.clear()
        scorePopups.clear()
        nextObstacleZ = 28f
        initTorches()

        _gameState.value = _gameState.value.copy(
            status = GameStatus.RUNNING,
            score = 0,
            distanceMeters = 0f,
            coinsThisRun = 0,
            gemsThisRun = 0,
            multiplier = 1,
            speed = speed,
            beastDistance = beastDistance,
            obstacles = emptyList(),
            collectibles = emptyList(),
            activePowerUps = emptyList(),
            particles = emptyList(),
            scorePopups = emptyList(),
            deathReason = ""
        )
    }

    fun pauseGame() {
        if (_gameState.value.status == GameStatus.RUNNING) {
            _gameState.value = _gameState.value.copy(status = GameStatus.PAUSED)
        }
    }

    fun resumeGame() {
        if (_gameState.value.status == GameStatus.PAUSED) {
            _gameState.value = _gameState.value.copy(status = GameStatus.RUNNING)
        }
    }

    fun reviveGame(): Boolean {
        if (preferences.spendCoins(100)) {
            // Revive with a 4-second invincibility shield burst!
            solarisUsedAegis = false
            beastDistance = 18f
            stumbleTimer = 0f
            isSliding = false
            currentJumpY = 0f
            // Clear immediate obstacles in front of player
            obstacles.removeAll { it.z < 20f }
            activePowerUps.removeAll { it.type == PowerUpType.SHIELD }
            activePowerUps.add(ActivePowerUp(PowerUpType.SHIELD, 5f, 5f))
            _gameState.value = _gameState.value.copy(
                status = GameStatus.RUNNING,
                beastDistance = 18f
            )
            onHapticFeedback("powerup")
            return true
        }
        return false
    }

    // Input handlers with fluid dodge physics
    fun moveLeft() {
        if (_gameState.value.status != GameStatus.RUNNING) return
        val prevLane = targetLane
        targetLane = targetLane.moveLeft()
        if (targetLane != prevLane) {
            // Spawn kick-back dust towards the right
            spawnParticles(currentLaneX + 0.15f, 0.05f, Color(0xFFD7CCC8), count = 5)
            onHapticFeedback("lane")
        }
    }

    fun moveRight() {
        if (_gameState.value.status != GameStatus.RUNNING) return
        val prevLane = targetLane
        targetLane = targetLane.moveRight()
        if (targetLane != prevLane) {
            // Spawn kick-back dust towards the left
            spawnParticles(currentLaneX - 0.15f, 0.05f, Color(0xFFD7CCC8), count = 5)
            onHapticFeedback("lane")
        }
    }

    fun jump() {
        if (_gameState.value.status != GameStatus.RUNNING) return
        // If sliding, cancel slide immediately and leap into the air
        if (isSliding) {
            isSliding = false
            slideTimer = 0f
        }
        if (currentJumpY <= 0.05f) {
            val char = _gameState.value.equippedCharacter
            // Maya Swift has higher jump hangtime perk
            val initialVelocity = if (char.id == "maya") 11.8f else 10.4f
            jumpVelocity = initialVelocity
            squashX = 0.82f
            squashY = 1.25f
            spawnParticles(currentLaneX, 0.05f, Color(0xFFB0BEC5), count = 7)
            onHapticFeedback("jump")

            // Cosmetic particle bursts on jump
            val cosmetic = _gameState.value.equippedCosmetic
            if (cosmetic?.id == "cyber_visor") {
                spawnParticles(currentLaneX, 0.2f, Color(0xFF00E5FF), count = 7)
            } else if (cosmetic?.id == "sun_crown") {
                spawnParticles(currentLaneX, 0.2f, Color(0xFFFFD54F), count = 7)
            }
        }
    }

    fun slide() {
        if (_gameState.value.status != GameStatus.RUNNING) return
        val char = _gameState.value.equippedCharacter
        // Maya has faster slide recovery, normal slide is 0.75s
        val duration = if (char.id == "maya") 0.60f else 0.75f
        isSliding = true
        slideTimer = duration
        if (currentJumpY > 0f) {
            // Fast fall dive slam downwards when pressing slide in midair!
            jumpVelocity = -22f
            spawnParticles(currentLaneX, 0.2f, Color(0xFFFFB74D), count = 6)
        }
        squashX = 1.32f
        squashY = 0.65f
        spawnParticles(currentLaneX, 0.05f, Color(0xFF8D6E63), count = 6)
        onHapticFeedback("slide")

        // Cosmetic particle bursts on slide
        val cosmetic = _gameState.value.equippedCosmetic
        if (cosmetic?.id == "oni_mask") {
            spawnParticles(currentLaneX, 0.1f, Color(0xFF00E5FF), count = 6)
        }
    }

    // Main Game Loop Update
    fun update(deltaTime: Float) {
        if (_gameState.value.status != GameStatus.RUNNING) return
        val dt = deltaTime.coerceIn(0.001f, 0.05f)

        // Speed increases gradually with distance
        val baseSpeed = 13.5f + (distanceMeters / 120f).coerceAtMost(10f)
        val isSpeedBoosting = activePowerUps.any { it.type == PowerUpType.SPEED_BOOST }
        speed = if (isSpeedBoosting) baseSpeed * 1.6f else baseSpeed

        distanceMeters += speed * dt
        val multBonus = activePowerUps.count { it.type == PowerUpType.MULTIPLIER_2X }
        val currentMult = (streakMultiplier + preferences.multiplierLevel.value - 1) * (if (multBonus > 0) 2 else 1)
        score += (speed * dt * currentMult * 1.8f).toInt()

        // Character perks: Kage has longer magnet duration
        val char = _gameState.value.equippedCharacter

        // Fluid smooth lane dodge with banking lean tilt
        val targetX = targetLane.index.toFloat()
        val laneDiff = targetX - currentLaneX
        val laneVelocity = laneDiff * 16.5f
        currentLaneX += laneVelocity * dt
        val targetTilt = (laneVelocity * 10.5f).coerceIn(-24f, 24f)
        currentTiltAngle += (targetTilt - currentTiltAngle) * (dt * 18f)

        // Fluid jump physics & dynamic squash/stretch
        if (currentJumpY > 0f || jumpVelocity != 0f) {
            val gravity = 25f
            currentJumpY += jumpVelocity * dt
            jumpVelocity -= gravity * dt

            if (jumpVelocity > 4f) {
                // Rising stretch
                squashX = 0.86f
                squashY = 1.20f
            } else if (jumpVelocity < -4f) {
                // Falling stretch
                squashX = 0.92f
                squashY = 1.12f
            } else {
                // Apex hangtime
                squashX = 1.0f
                squashY = 1.0f
            }

            if (currentJumpY <= 0f) {
                currentJumpY = 0f
                jumpVelocity = 0f
                landingSquashTimer = 0.12f
                spawnParticles(currentLaneX, 0.05f, Color(0xFFB0BEC5), count = 6)
            }
        }

        // Landing impact or recovery
        if (landingSquashTimer > 0f) {
            landingSquashTimer -= dt
            squashX = 1.22f
            squashY = 0.80f
        } else if (!isSliding) {
            squashX += (1.0f - squashX) * (dt * 14f)
            squashY += (1.0f - squashY) * (dt * 14f)
        }

        // Slide timer & continuous slide friction sparks
        if (isSliding) {
            slideTimer -= dt
            squashX = 1.30f
            squashY = 0.65f
            if (Random.nextFloat() < 0.25f) {
                spawnParticles(currentLaneX, 0.05f, Color(0xFFFFCC80), count = 2)
            }
            if (slideTimer <= 0f) {
                isSliding = false
                slideTimer = 0f
                squashX = 1.0f
                squashY = 1.0f
            }
        }

        // Stumble timer & Beast pursuit logic
        if (stumbleTimer > 0f) {
            stumbleTimer -= dt
        }

        // Beast logic: if no stumbling for a while, retreats to safe distance
        if (stumbleTimer <= 0f && beastDistance < 18f) {
            beastDistance += dt * 0.8f
        }

        // Step animation cycle
        runStepTimer = (runStepTimer + dt * (speed * 0.4f)) % 1.0f

        // Update active powerups
        val itPower = activePowerUps.iterator()
        while (itPower.hasNext()) {
            val p = itPower.next()
            p.remainingTime -= dt
            if (p.remainingTime <= 0f) {
                itPower.remove()
            }
        }

        // Spawn world elements
        spawnTrackElements(dt)

        // Move obstacles
        val itObs = obstacles.iterator()
        val isInvincible = isSpeedBoosting || activePowerUps.any { it.type == PowerUpType.SHIELD }

        while (itObs.hasNext()) {
            val obs = itObs.next()
            obs.z -= speed * dt

            // Collision check window (when obstacle passes near player Z = 0)
            if (!obs.cleared && !obs.hit && obs.z in -0.6f..0.8f) {
                checkObstacleCollision(obs, isInvincible)
            }

            // Remove passed obstacles
            if (obs.z < -6f) {
                itObs.remove()
            }
        }

        // Move & collect items
        val isMagnetActive = activePowerUps.any { it.type == PowerUpType.MAGNET }
        val magnetRange = if (char.id == "kage") 8.5f else 5.5f

        val itCol = collectibles.iterator()
        while (itCol.hasNext()) {
            val col = itCol.next()
            col.z -= speed * dt

            // Magnet attraction
            if (isMagnetActive && col.type == CollectibleType.COIN && col.z in 0.5f..magnetRange) {
                // pull toward player lane and forward
                val laneDiff = currentLaneX - col.lane.index.toFloat()
                col.z -= dt * 14f
            }

            // Collection check near player
            if (!col.collected && col.z in -0.4f..1.1f) {
                val laneMatch = kotlin.math.abs(col.lane.index.toFloat() - currentLaneX) < 0.65f
                val heightMatch = if (col.yHeight > 0.4f) currentJumpY > 0.35f else !isSliding || col.yHeight < 0.2f
                if (laneMatch && (heightMatch || isMagnetActive)) {
                    collectItem(col)
                }
            }

            if (col.z < -5f) {
                itCol.remove()
            }
        }

        // Update particles
        val itPart = particles.iterator()
        while (itPart.hasNext()) {
            val p = itPart.next()
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.life -= dt
            p.alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
            if (p.life <= 0f) {
                itPart.remove()
            }
        }

        // Update score popups
        val itPop = scorePopups.iterator()
        while (itPop.hasNext()) {
            val pop = itPop.next()
            pop.y -= dt * 60f
            pop.life -= dt * 1.5f
            pop.alpha = pop.life.coerceIn(0f, 1f)
            if (pop.life <= 0f) {
                itPop.remove()
            }
        }

        // Move torches
        for (torch in torches) {
            val newZ = (torch.z - speed * dt)
            // wrap around
            val wrappedZ = if (newZ < 0f) newZ + 120f else newZ
            torches[torches.indexOf(torch)] = torch.copy(
                z = wrappedZ,
                flameFlicker = 0.8f + 0.4f * sin((distanceMeters * 2f + wrappedZ).toDouble()).toFloat()
            )
        }

        // Publish updated state
        _gameState.value = _gameState.value.copy(
            score = score,
            distanceMeters = distanceMeters,
            coinsThisRun = coinsThisRun,
            gemsThisRun = gemsThisRun,
            multiplier = currentMult,
            speed = speed,
            beastDistance = beastDistance,
            player = PlayerVisualState(
                laneX = currentLaneX,
                jumpY = currentJumpY,
                isSliding = isSliding,
                slideProgress = if (isSliding) (slideTimer / 0.75f) else 0f,
                runStepCycle = runStepTimer,
                isInvincible = isInvincible,
                isShielded = activePowerUps.any { it.type == PowerUpType.SHIELD },
                isMagnetActive = isMagnetActive,
                isSpeedBoosting = isSpeedBoosting,
                isStumbling = stumbleTimer > 0f,
                tiltAngle = currentTiltAngle,
                squashX = squashX,
                squashY = squashY
            ),
            obstacles = obstacles.toList(),
            collectibles = collectibles.toList(),
            activePowerUps = activePowerUps.toList(),
            particles = particles.toList(),
            scorePopups = scorePopups.toList(),
            torches = torches.toList()
        )
    }

    private fun checkObstacleCollision(obs: Obstacle, isInvincible: Boolean) {
        val laneDiff = kotlin.math.abs(obs.lane.index.toFloat() - currentLaneX)
        if (laneDiff < 0.65f) {
            // In the same lane! Check if cleared by proper move
            var cleared = false
            when (obs.type.requirement) {
                ObstacleRequirement.JUMP -> {
                    if (currentJumpY > 0.35f) {
                        cleared = true
                        addScorePopup("+50 JUMP!", Color(0xFF00E676), 0f, 120f)
                    }
                }
                ObstacleRequirement.SLIDE -> {
                    if (isSliding) {
                        cleared = true
                        addScorePopup("+50 SLIDE!", Color(0xFF00E5FF), 0f, 120f)
                    }
                }
                ObstacleRequirement.DODGE -> {
                    cleared = false
                }
            }

            if (cleared) {
                obs.cleared = true
                streakCounter++
                if (streakCounter % 5 == 0 && streakMultiplier < 5) {
                    streakMultiplier++
                    addScorePopup("${streakMultiplier}X STREAK!", Color(0xFFFFD54F), 0f, 80f)
                }
            } else {
                // Collided!
                obs.hit = true
                handleObstacleHit(obs, isInvincible)
            }
        } else {
            // Cleared by being in another lane
            obs.cleared = true
        }
    }

    private fun handleObstacleHit(obs: Obstacle, isInvincible: Boolean) {
        if (isInvincible) {
            // Smashes through obstacle!
            spawnParticles(currentLaneX, 0.4f, obs.type.color, count = 12)
            addScorePopup("SMASH!", Color(0xFFFFD54F), 0f, 100f)
            onHapticFeedback("smash")
            return
        }

        val char = _gameState.value.equippedCharacter
        // Solaris Sun Golem perk: Survives 1 fatal hit per run with free shield burst!
        if (char.id == "solaris" && !solarisUsedAegis) {
            solarisUsedAegis = true
            activePowerUps.add(ActivePowerUp(PowerUpType.SHIELD, 3.5f, 3.5f))
            spawnParticles(currentLaneX, 0.5f, Color(0xFFFF8F00), count = 16)
            addScorePopup("SOLAR AEGIS SAVED YOU!", Color(0xFFFF8F00), 0f, 100f)
            onHapticFeedback("powerup")
            return
        }

        // Check if minor stumble or fatal crash
        val isFatalObstacle = obs.type == ObstacleType.CRUMBLING_PILLAR || obs.type == ObstacleType.STONE_BLOCK

        if (isFatalObstacle || beastDistance <= 4.5f) {
            // Fatal crash or beast caught player!
            gameOver(
                if (beastDistance <= 4.5f) "The Temple Demon caught you!"
                else "Crashed into ${obs.type.displayName}!"
            )
        } else {
            // Stumble! Beast surges closer!
            stumbleTimer = 2.0f
            beastDistance = (beastDistance - 8f).coerceAtLeast(3f)
            streakMultiplier = 1
            streakCounter = 0
            spawnParticles(currentLaneX, 0.2f, Color(0xFFFF5722), count = 8)
            addScorePopup("STUMBLE! BEAST APPROACHES!", Color(0xFFFF3D00), 0f, 100f)
            onHapticFeedback("stumble")
        }
    }

    private fun collectItem(col: Collectible) {
        col.collected = true
        when (col.type) {
            CollectibleType.COIN -> {
                coinsThisRun++
                score += 25
                addScorePopup("+1", Color(0xFFFFD54F), currentLaneX * 40f, 150f)
                onHapticFeedback("coin")
            }
            CollectibleType.EMERALD -> {
                gemsThisRun++
                coinsThisRun += 5
                score += 150
                addScorePopup("+5 GEMS!", Color(0xFF00E676), currentLaneX * 40f, 130f)
                onHapticFeedback("powerup")
            }
            CollectibleType.MAGNET -> {
                val lvl = preferences.magnetLevel.value
                val dur = (10f + lvl * 2f)
                activatePowerUp(PowerUpType.MAGNET, dur)
                addScorePopup("MAGNET!", Color(0xFFFFEA00), 0f, 100f)
                onHapticFeedback("powerup")
            }
            CollectibleType.SHIELD -> {
                val lvl = preferences.shieldLevel.value
                val dur = (10f + lvl * 2f)
                activatePowerUp(PowerUpType.SHIELD, dur)
                addScorePopup("SHIELD!", Color(0xFF2979FF), 0f, 100f)
                onHapticFeedback("powerup")
            }
            CollectibleType.SPEED_BOOST -> {
                val lvl = preferences.boostLevel.value
                val dur = (6f + lvl * 1.5f)
                activatePowerUp(PowerUpType.SPEED_BOOST, dur)
                addScorePopup("RELIC RUSH!", Color(0xFFFF6D00), 0f, 100f)
                onHapticFeedback("powerup")
            }
            CollectibleType.MULTIPLIER_2X -> {
                activatePowerUp(PowerUpType.MULTIPLIER_2X, 12f)
                addScorePopup("2X MULTIPLIER!", Color(0xFFB388FF), 0f, 100f)
                onHapticFeedback("powerup")
            }
        }
    }

    private fun activatePowerUp(type: PowerUpType, duration: Float) {
        activePowerUps.removeAll { it.type == type }
        activePowerUps.add(ActivePowerUp(type, duration, duration))
    }

    private fun spawnTrackElements(dt: Float) {
        val maxSpawnZ = 90f

        // Check if we need to spawn next obstacle
        if (obstacles.isEmpty() || obstacles.maxOf { it.z } < maxSpawnZ - 20f) {
            spawnObstacleGroup(maxSpawnZ)
        }

        // Spawn collectible lines/arcs
        if (collectibles.isEmpty() || collectibles.maxOf { it.z } < maxSpawnZ - 12f) {
            spawnCollectibleCluster(maxSpawnZ)
        }
    }

    private fun spawnObstacleGroup(startZ: Float) {
        val randomType = ObstacleType.values().random()
        val randomLane = Lane.values().random()
        val z = startZ + Random.nextFloat() * 10f

        obstacles.add(
            Obstacle(
                id = idCounter++,
                lane = randomLane,
                z = z,
                type = randomType
            )
        )

        // Occasionally spawn twin obstacles in different lanes on higher speeds
        if (speed > 18f && Random.nextFloat() < 0.35f) {
            val otherLanes = Lane.values().filter { it != randomLane }
            val otherLane = otherLanes.random()
            val safeType = if (randomType.requirement == ObstacleRequirement.JUMP) ObstacleType.TREE_LOG else ObstacleType.FIRE_PIT
            obstacles.add(
                Obstacle(
                    id = idCounter++,
                    lane = otherLane,
                    z = z,
                    type = safeType
                )
            )
        }
    }

    private fun spawnCollectibleCluster(startZ: Float) {
        val lane = Lane.values().random()
        val isHighArc = Random.nextBoolean()
        val count = Random.nextInt(4, 7)

        for (i in 0 until count) {
            val z = startZ + i * 3.2f
            val y = if (isHighArc) {
                // Arc shape up and down for jumps
                sin(i.toFloat() / (count - 1).toFloat() * Math.PI).toFloat() * 1.1f
            } else 0f

            collectibles.add(
                Collectible(
                    id = idCounter++,
                    lane = lane,
                    z = z,
                    yHeight = y,
                    type = CollectibleType.COIN
                )
            )
        }

        // Rare power-up or emerald spawn
        if (Random.nextFloat() < 0.22f) {
            val powerUpLane = Lane.values().filter { it != lane }.random()
            val powerUpTypes = listOf(
                CollectibleType.EMERALD,
                CollectibleType.MAGNET,
                CollectibleType.SHIELD,
                CollectibleType.SPEED_BOOST,
                CollectibleType.MULTIPLIER_2X
            )
            collectibles.add(
                Collectible(
                    id = idCounter++,
                    lane = powerUpLane,
                    z = startZ + count * 2f + 5f,
                    yHeight = 0.2f,
                    type = powerUpTypes.random()
                )
            )
        }
    }

    private fun spawnParticles(laneX: Float, y: Float, color: Color, count: Int) {
        for (i in 0 until count) {
            val angle = Random.nextFloat() * Math.PI * 2
            val spd = Random.nextFloat() * 80f + 30f
            particles.add(
                Particle(
                    x = laneX * 80f,
                    y = y * 100f,
                    vx = (kotlin.math.cos(angle) * spd).toFloat(),
                    vy = (kotlin.math.sin(angle) * spd).toFloat() - 40f,
                    color = color,
                    alpha = 1f,
                    size = Random.nextFloat() * 6f + 4f,
                    life = 0.6f,
                    maxLife = 0.6f
                )
            )
        }
    }

    private fun addScorePopup(text: String, color: Color, x: Float, y: Float) {
        scorePopups.add(
            ScorePopup(
                id = idCounter++,
                text = text,
                color = color,
                x = x,
                y = y
            )
        )
    }

    private fun gameOver(reason: String) {
        _gameState.value = _gameState.value.copy(
            status = GameStatus.GAME_OVER,
            deathReason = reason
        )
        preferences.addCoins(coinsThisRun)
        preferences.saveHighScore(score)
        preferences.recordRunCompleted(distanceMeters, coinsThisRun)
        onHapticFeedback("game_over")
    }
}
