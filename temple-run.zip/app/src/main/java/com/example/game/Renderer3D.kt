package com.example.game

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import com.example.model.*
import kotlin.math.sin

object Renderer3D {

    private sealed class RenderItem(val z: Float) {
        class ObsItem(val obs: Obstacle) : RenderItem(obs.z)
        class ColItem(val col: Collectible) : RenderItem(col.z)
    }

    data class ProjectedPoint(
        val x: Float,
        val y: Float,
        val scale: Float
    )

    fun project(
        laneX: Float,
        heightY: Float,
        z: Float,
        width: Float,
        height: Float
    ): ProjectedPoint {
        val horizonX = width * 0.5f
        val horizonY = height * 0.35f
        val groundBaselineY = height * 0.82f
        val laneSpacingBase = width * 0.28f

        // Perspective factor
        val scale = 1.0f / (1.0f + (z.coerceAtLeast(0.1f)) * 0.065f)

        val groundY = horizonY + (groundBaselineY - horizonY) * scale
        val screenX = horizonX + (laneX * laneSpacingBase) * scale
        val screenY = groundY - (heightY * height * 0.18f) * scale

        return ProjectedPoint(screenX, screenY, scale)
    }

    fun render(
        scope: DrawScope,
        state: GameState,
        width: Float,
        height: Float
    ) {
        val horizonX = width * 0.5f
        val horizonY = height * 0.35f
        val groundBaselineY = height * 0.82f

        // 1. Draw Sky & Jungle Ruins Background
        drawSkyAndJungle(scope, width, height, horizonY)

        // 2. Draw Temple Stone Track with Perspective
        drawTrack(scope, width, height, horizonX, horizonY, groundBaselineY, state.distanceMeters)

        // 3. Draw Side Torches & Braziers
        drawTorches(scope, state.torches, width, height)

        // 4. Collect & Depth-Sort approaching objects (Obstacles & Collectibles)
        drawWorldObjects(scope, state, width, height)

        // 5. Draw Chasing Temple Demon Beast (behind player)
        if (state.beastDistance < 16f) {
            drawDemonBeast(scope, state, width, height)
        }

        // 6. Draw Player Character in Perspective with Custom Gear
        drawPlayerCharacter(scope, state, width, height)

        // 7. Draw Active Aura & Speed Trails
        drawPlayerAuras(scope, state, width, height)

        // 8. Draw Particles & Dust
        drawParticles(scope, state.particles, width, height)

        // 9. Draw Floating Score Popups
        drawScorePopups(scope, state.scorePopups, width, height)
    }

    private fun drawSkyAndJungle(
        scope: DrawScope,
        width: Float,
        height: Float,
        horizonY: Float
    ) {
        // Mystical Aztec canopy gradient
        scope.drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF0F1E19), // Deep canopy green
                    Color(0xFF1E322A),
                    Color(0xFF332014), // Golden dusk
                    Color(0xFF5D381A)
                ),
                startY = 0f,
                endY = horizonY
            ),
            size = Size(width, horizonY)
        )

        // Sun / Aztec Golden Horizon Glow
        scope.drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x99FFA000), Color(0x33FF6F00), Color(0x00000000)),
                center = Offset(width * 0.5f, horizonY),
                radius = width * 0.45f
            ),
            radius = width * 0.45f,
            center = Offset(width * 0.5f, horizonY)
        )

        // Ancient Pyramid Silhouettes on horizon
        val pyramidPath = Path().apply {
            moveTo(width * 0.15f, horizonY)
            lineTo(width * 0.28f, horizonY - 45f)
            lineTo(width * 0.35f, horizonY - 45f)
            lineTo(width * 0.48f, horizonY)
            close()
            moveTo(width * 0.55f, horizonY)
            lineTo(width * 0.70f, horizonY - 60f)
            lineTo(width * 0.78f, horizonY - 60f)
            lineTo(width * 0.90f, horizonY)
            close()
        }
        scope.drawPath(pyramidPath, Color(0xFF1B261D))
    }

    private fun drawTrack(
        scope: DrawScope,
        width: Float,
        height: Float,
        horizonX: Float,
        horizonY: Float,
        groundBaselineY: Float,
        distanceRun: Float
    ) {
        val roadTopHalfWidth = width * 0.12f
        val roadBottomHalfWidth = width * 0.46f

        // Ancient Temple Stone Path Floor
        val trackPath = Path().apply {
            moveTo(horizonX - roadTopHalfWidth, horizonY)
            lineTo(horizonX + roadTopHalfWidth, horizonY)
            lineTo(horizonX + roadBottomHalfWidth, height)
            lineTo(horizonX - roadBottomHalfWidth, height)
            close()
        }

        // Stone Road Gradient
        scope.drawPath(
            path = trackPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF231C16), // Dark stone near horizon
                    Color(0xFF382D24),
                    Color(0xFF4A3C30)  // Textured warm stone foreground
                ),
                startY = horizonY,
                endY = height
            )
        )

        // Lane Divider Lines
        for (laneIdx in listOf(-0.33f, 0.33f)) {
            val topX = horizonX + roadTopHalfWidth * laneIdx * 2f
            val botX = horizonX + roadBottomHalfWidth * laneIdx * 2f
            scope.drawLine(
                color = Color(0x44FFD54F),
                start = Offset(topX, horizonY),
                end = Offset(botX, height),
                strokeWidth = 2.5f
            )
        }

        // Stone Border Curbs with Carvings
        val leftCurb = Path().apply {
            moveTo(horizonX - roadTopHalfWidth - 8f, horizonY)
            lineTo(horizonX - roadTopHalfWidth, horizonY)
            lineTo(horizonX - roadBottomHalfWidth, height)
            lineTo(horizonX - roadBottomHalfWidth - 30f, height)
            close()
        }
        scope.drawPath(leftCurb, Color(0xFF2E241D))

        val rightCurb = Path().apply {
            moveTo(horizonX + roadTopHalfWidth, horizonY)
            lineTo(horizonX + roadTopHalfWidth + 8f, horizonY)
            lineTo(horizonX + roadBottomHalfWidth + 30f, height)
            lineTo(horizonX + roadBottomHalfWidth, height)
            close()
        }
        scope.drawPath(rightCurb, Color(0xFF2E241D))

        // Horizontal Stone Slab Cracks (Scrolling backward with distance)
        val slabSpacing = 4f
        val scrollOffset = distanceRun % slabSpacing
        for (i in 0..20) {
            val z = i * slabSpacing - scrollOffset
            if (z > 0.5f) {
                val pLeft = project(-1.5f, 0f, z, width, height)
                val pRight = project(1.5f, 0f, z, width, height)
                val alpha = (pLeft.scale * 0.7f).coerceIn(0.1f, 0.6f)
                scope.drawLine(
                    color = Color(0x33100B06).copy(alpha = alpha),
                    start = Offset(pLeft.x, pLeft.y),
                    end = Offset(pRight.x, pRight.y),
                    strokeWidth = 3f * pLeft.scale
                )
            }
        }
    }

    private fun drawTorches(
        scope: DrawScope,
        torches: List<Torch>,
        width: Float,
        height: Float
    ) {
        for (torch in torches) {
            val laneX = if (torch.isLeft) -1.75f else 1.75f
            val base = project(laneX, 0f, torch.z, width, height)
            val top = project(laneX, 0.45f, torch.z, width, height)

            if (base.scale > 0.08f) {
                // Torch Post
                scope.drawLine(
                    color = Color(0xFF3E2723),
                    start = Offset(base.x, base.y),
                    end = Offset(top.x, top.y),
                    strokeWidth = 5f * base.scale
                )

                // Torch Flame & Ember Glow
                val flameRadius = 10f * base.scale * torch.flameFlicker
                scope.drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFFFFEA00), Color(0xFFFF5722), Color(0x00FF3D00)),
                        center = Offset(top.x, top.y),
                        radius = flameRadius * 2.2f
                    ),
                    radius = flameRadius * 2.2f,
                    center = Offset(top.x, top.y)
                )
                scope.drawCircle(
                    color = Color(0xFFFFD54F),
                    radius = flameRadius,
                    center = Offset(top.x, top.y)
                )
            }
        }
    }

    private fun drawWorldObjects(
        scope: DrawScope,
        state: GameState,
        width: Float,
        height: Float
    ) {
        val items = mutableListOf<RenderItem>()
        for (o in state.obstacles) {
            if (o.z > 0.1f && !o.hit) items.add(RenderItem.ObsItem(o))
        }
        for (c in state.collectibles) {
            if (c.z > 0.1f && !c.collected) items.add(RenderItem.ColItem(c))
        }

        // Sort descending by Z (farthest first)
        items.sortByDescending { it.z }

        for (item in items) {
            when (item) {
                is RenderItem.ObsItem -> drawObstacle(scope, item.obs, width, height)
                is RenderItem.ColItem -> drawCollectible(scope, item.col, width, height, state.distanceMeters)
            }
        }
    }

    private fun drawObstacle(
        scope: DrawScope,
        obs: Obstacle,
        width: Float,
        height: Float
    ) {
        val p = project(obs.lane.index.toFloat(), 0f, obs.z, width, height)
        val scale = p.scale
        if (scale < 0.08f) return

        val laneWidthPx = (width * 0.28f) * scale

        when (obs.type) {
            ObstacleType.TREE_LOG -> {
                // Low obstacle: Jump required
                val logHeight = 24f * scale
                val logWidth = laneWidthPx * 1.15f
                scope.drawRoundRect(
                    color = Color(0xFF4E342E),
                    topLeft = Offset(p.x - logWidth * 0.5f, p.y - logHeight),
                    size = Size(logWidth, logHeight),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f * scale)
                )
                // Moss accents on log
                scope.drawRect(
                    color = Color(0xFF2E7D32),
                    topLeft = Offset(p.x - logWidth * 0.4f, p.y - logHeight),
                    size = Size(logWidth * 0.8f, logHeight * 0.35f)
                )
            }
            ObstacleType.FIRE_PIT -> {
                // Brazier with fire
                val bWidth = laneWidthPx * 0.9f
                val bHeight = 30f * scale
                scope.drawRect(
                    color = Color(0xFF37474F),
                    topLeft = Offset(p.x - bWidth * 0.5f, p.y - bHeight * 0.6f),
                    size = Size(bWidth, bHeight * 0.6f)
                )
                // Fire flame
                scope.drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFFFFEB3B), Color(0xFFFF5722), Color(0x00FF3D00)),
                        center = Offset(p.x, p.y - bHeight * 0.8f),
                        radius = bWidth * 0.6f
                    ),
                    radius = bWidth * 0.6f,
                    center = Offset(p.x, p.y - bHeight * 0.8f)
                )
            }
            ObstacleType.SPIKE_TRAP -> {
                val sWidth = laneWidthPx * 0.9f
                val sHeight = 22f * scale
                val path = Path().apply {
                    val count = 4
                    val step = sWidth / count
                    moveTo(p.x - sWidth * 0.5f, p.y)
                    for (i in 0 until count) {
                        val startX = p.x - sWidth * 0.5f + i * step
                        lineTo(startX + step * 0.5f, p.y - sHeight)
                        lineTo(startX + step, p.y)
                    }
                    close()
                }
                scope.drawPath(path, Color(0xFF78909C))
            }
            ObstacleType.TEMPLE_ARCH -> {
                // High obstacle: Slide required (overhead stone arch)
                val archWidth = laneWidthPx * 1.3f
                val archHeight = 90f * scale
                val clearance = 42f * scale // space underneath to slide

                // Left & Right Pillars
                val pillarW = 14f * scale
                scope.drawRect(
                    color = Color(0xFF3E2723),
                    topLeft = Offset(p.x - archWidth * 0.5f, p.y - archHeight),
                    size = Size(pillarW, archHeight)
                )
                scope.drawRect(
                    color = Color(0xFF3E2723),
                    topLeft = Offset(p.x + archWidth * 0.5f - pillarW, p.y - archHeight),
                    size = Size(pillarW, archHeight)
                )
                // Overhead Arch Beam
                scope.drawRoundRect(
                    color = Color(0xFF4E342E),
                    topLeft = Offset(p.x - archWidth * 0.5f, p.y - archHeight),
                    size = Size(archWidth, archHeight - clearance),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f * scale)
                )
                // Carved Aztec glyph mark
                scope.drawCircle(
                    color = Color(0xFFFFD54F),
                    radius = 8f * scale,
                    center = Offset(p.x, p.y - archHeight + (archHeight - clearance) * 0.5f)
                )
            }
            ObstacleType.BLADE_PENDULUM -> {
                val bWidth = laneWidthPx * 1.1f
                val bHeight = 85f * scale
                val bladeY = p.y - 38f * scale
                // Swinging cord
                scope.drawLine(
                    color = Color(0xFF263238),
                    start = Offset(p.x, p.y - bHeight),
                    end = Offset(p.x, bladeY),
                    strokeWidth = 3f * scale
                )
                // Crescent blade
                scope.drawCircle(
                    color = Color(0xFFCFD8DC),
                    radius = 22f * scale,
                    center = Offset(p.x, bladeY)
                )
            }
            ObstacleType.CRUMBLING_PILLAR, ObstacleType.STONE_BLOCK -> {
                // Full obstacle: Lane dodge required
                val pillarWidth = laneWidthPx * 0.85f
                val pillarHeight = 110f * scale
                scope.drawRoundRect(
                    color = Color(0xFF37474F),
                    topLeft = Offset(p.x - pillarWidth * 0.5f, p.y - pillarHeight),
                    size = Size(pillarWidth, pillarHeight),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f * scale)
                )
                // Glowing idol face carving
                scope.drawCircle(
                    color = Color(0xFFFF9800),
                    radius = 10f * scale,
                    center = Offset(p.x, p.y - pillarHeight * 0.7f)
                )
            }
        }
    }

    private fun drawCollectible(
        scope: DrawScope,
        col: Collectible,
        width: Float,
        height: Float,
        distanceRun: Float
    ) {
        val p = project(col.lane.index.toFloat(), col.yHeight, col.z, width, height)
        val scale = p.scale
        if (scale < 0.08f) return

        when (col.type) {
            CollectibleType.COIN -> {
                val radius = 16f * scale
                // Gold coin with spinning shine
                val spinRatio = kotlin.math.abs(sin((distanceRun * 3f + col.z).toDouble())).toFloat().coerceIn(0.2f, 1f)
                val coinW = radius * spinRatio

                scope.drawOval(
                    color = Color(0xFFFFD54F),
                    topLeft = Offset(p.x - coinW, p.y - radius),
                    size = Size(coinW * 2f, radius * 2f)
                )
                // Inner rim
                scope.drawOval(
                    color = Color(0xFFFF8F00),
                    topLeft = Offset(p.x - coinW * 0.65f, p.y - radius * 0.65f),
                    size = Size(coinW * 1.3f, radius * 1.3f),
                    style = Stroke(width = 2f * scale)
                )
            }
            CollectibleType.EMERALD -> {
                val size = 20f * scale
                // Radiant green gem diamond
                val gemPath = Path().apply {
                    moveTo(p.x, p.y - size)
                    lineTo(p.x + size, p.y)
                    lineTo(p.x, p.y + size)
                    lineTo(p.x - size, p.y)
                    close()
                }
                scope.drawPath(gemPath, Color(0xFF00E676))
                scope.drawCircle(
                    color = Color(0x88A7FFEB),
                    radius = size * 0.4f,
                    center = Offset(p.x, p.y)
                )
            }
            CollectibleType.MAGNET, CollectibleType.SHIELD, CollectibleType.SPEED_BOOST, CollectibleType.MULTIPLIER_2X -> {
                val orbRadius = 24f * scale
                // Powerup glowing orb
                scope.drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(col.type.color, col.type.color.copy(alpha = 0.5f), Color.Transparent),
                        center = Offset(p.x, p.y),
                        radius = orbRadius * 1.8f
                    ),
                    radius = orbRadius * 1.8f,
                    center = Offset(p.x, p.y)
                )
                scope.drawCircle(
                    color = col.type.color,
                    radius = orbRadius,
                    center = Offset(p.x, p.y)
                )
                scope.drawCircle(
                    color = Color.White,
                    radius = orbRadius * 0.35f,
                    center = Offset(p.x, p.y)
                )
            }
        }
    }

    private fun drawDemonBeast(
        scope: DrawScope,
        state: GameState,
        width: Float,
        height: Float
    ) {
        // Rendered behind player (at z = state.beastDistance)
        // If distance is <= 15m, becomes visible and looms behind!
        val beastZ = (state.beastDistance - 14f).coerceAtLeast(0.3f)
        val p = project(state.player.laneX, 0f, beastZ, width, height)
        val scale = p.scale
        if (scale < 0.1f) return

        val beastW = 85f * scale
        val beastH = 110f * scale

        // Beast Dark Demon Gorilla / Idol Body
        scope.drawOval(
            color = Color(0xFF140D07),
            topLeft = Offset(p.x - beastW * 0.5f, p.y - beastH),
            size = Size(beastW, beastH)
        )

        // Beast Horns
        val hornPath = Path().apply {
            moveTo(p.x - beastW * 0.35f, p.y - beastH * 0.85f)
            lineTo(p.x - beastW * 0.65f, p.y - beastH * 1.15f)
            lineTo(p.x - beastW * 0.2f, p.y - beastH * 0.85f)
            close()
            moveTo(p.x + beastW * 0.35f, p.y - beastH * 0.85f)
            lineTo(p.x + beastW * 0.65f, p.y - beastH * 1.15f)
            lineTo(p.x + beastW * 0.2f, p.y - beastH * 0.85f)
            close()
        }
        scope.drawPath(hornPath, Color(0xFF3E2723))

        // Glowing Demonic Red Eyes
        val eyeW = 10f * scale
        val eyeH = 6f * scale
        scope.drawOval(
            color = Color(0xFFFF1744),
            topLeft = Offset(p.x - beastW * 0.25f, p.y - beastH * 0.72f),
            size = Size(eyeW, eyeH)
        )
        scope.drawOval(
            color = Color(0xFFFF1744),
            topLeft = Offset(p.x + beastW * 0.25f - eyeW, p.y - beastH * 0.72f),
            size = Size(eyeW, eyeH)
        )

        // Beast Reach Claws
        val clawW = 28f * scale
        scope.drawCircle(
            color = Color(0xFF26190E),
            radius = clawW * 0.5f,
            center = Offset(p.x - beastW * 0.55f, p.y - beastH * 0.35f)
        )
        scope.drawCircle(
            color = Color(0xFF26190E),
            radius = clawW * 0.5f,
            center = Offset(p.x + beastW * 0.55f, p.y - beastH * 0.35f)
        )
    }

    private fun drawPlayerCharacter(
        scope: DrawScope,
        state: GameState,
        width: Float,
        height: Float
    ) {
        val char = state.equippedCharacter
        val cosmetic = state.equippedCosmetic
        val player = state.player

        val basePoint = project(player.laneX, 0f, 0.6f, width, height)
        val charPoint = project(player.laneX, player.jumpY, 0.6f, width, height)
        val scale = charPoint.scale

        val charW = 48f * scale
        val charH = if (player.isSliding) 28f * scale else 80f * scale

        // 1. Ground Shadow (shrinks when jumping high)
        val shadowW = (charW * (1.1f - player.jumpY * 0.35f)).coerceAtLeast(16f * scale)
        val shadowH = 14f * scale
        scope.drawOval(
            color = Color(0x66000000),
            topLeft = Offset(basePoint.x - shadowW * 0.5f, basePoint.y - shadowH * 0.5f),
            size = Size(shadowW, shadowH)
        )

        val posX = charPoint.x
        val posY = charPoint.y

        // Apply fluid physics transforms: banking tilt angle and squash/stretch around player center
        scope.drawContext.canvas.save()
        scope.drawContext.canvas.translate(posX, posY)
        scope.drawContext.canvas.rotate(player.tiltAngle)
        scope.drawContext.canvas.scale(player.squashX, player.squashY)
        scope.drawContext.canvas.translate(-posX, -posY)

        if (player.isSliding) {
            // SLIDING POSE: Low crawl / slide along stone floor
            val slideW = 65f * scale
            val slideH = 26f * scale

            // Dust streak behind slide
            scope.drawOval(
                color = Color(0x44D7CCC8),
                topLeft = Offset(posX - slideW * 0.6f, posY - 8f * scale),
                size = Size(slideW * 1.2f, 16f * scale)
            )

            // Torso & Legs sliding horizontal
            scope.drawRoundRect(
                color = char.pantsColor,
                topLeft = Offset(posX - slideW * 0.45f, posY - slideH),
                size = Size(slideW * 0.5f, slideH * 0.9f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f * scale)
            )
            scope.drawRoundRect(
                color = char.shirtColor,
                topLeft = Offset(posX, posY - slideH),
                size = Size(slideW * 0.45f, slideH * 0.9f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f * scale)
            )

            // Head ducked low
            val headRadius = 11f * scale
            scope.drawCircle(
                color = char.skinColor,
                radius = headRadius,
                center = Offset(posX + slideW * 0.45f, posY - slideH * 0.6f)
            )

            // Draw equipped cosmetic during slide
            drawCosmeticItem(scope, cosmetic, posX + slideW * 0.45f, posY - slideH * 0.6f, scale, isSliding = true)

        } else {
            // UPRIGHT RUNNING & JUMPING POSE

            // Leg Swings (animated via runStepCycle)
            val legSwing = if (player.jumpY > 0.1f) 0f else sin(player.runStepCycle * Math.PI * 2).toFloat()
            val legW = 12f * scale
            val legH = 28f * scale
            val legY = posY - legH

            // Left Leg
            scope.drawRoundRect(
                color = char.pantsColor,
                topLeft = Offset(posX - charW * 0.35f, legY + legSwing * 10f * scale),
                size = Size(legW, legH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f * scale)
            )
            // Right Leg
            scope.drawRoundRect(
                color = char.pantsColor,
                topLeft = Offset(posX + charW * 0.35f - legW, legY - legSwing * 10f * scale),
                size = Size(legW, legH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f * scale)
            )

            // Torso / Shirt
            val torsoW = charW * 0.75f
            val torsoH = 34f * scale
            val torsoY = legY - torsoH
            scope.drawRoundRect(
                color = char.shirtColor,
                topLeft = Offset(posX - torsoW * 0.5f, torsoY),
                size = Size(torsoW, torsoH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f * scale)
            )

            // Belt & Buckle
            scope.drawRect(
                color = char.accentColor,
                topLeft = Offset(posX - torsoW * 0.5f, torsoY + torsoH - 6f * scale),
                size = Size(torsoW, 5f * scale)
            )

            // Arms Swinging
            val armW = 9f * scale
            val armH = 24f * scale
            scope.drawRoundRect(
                color = char.skinColor,
                topLeft = Offset(posX - torsoW * 0.5f - armW, torsoY + 4f * scale - legSwing * 8f * scale),
                size = Size(armW, armH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f * scale)
            )
            scope.drawRoundRect(
                color = char.skinColor,
                topLeft = Offset(posX + torsoW * 0.5f, torsoY + 4f * scale + legSwing * 8f * scale),
                size = Size(armW, armH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f * scale)
            )

            // Head
            val headRadius = 14f * scale
            val headCenterY = torsoY - headRadius
            scope.drawCircle(
                color = char.skinColor,
                radius = headRadius,
                center = Offset(posX, headCenterY)
            )

            // Hair / Headdress (Base Character Hat or Specific Hair)
            when (char.id) {
                "harrison" -> {
                    // Classic Adventurer Brown Fedora
                    val hatBrimW = 34f * scale
                    scope.drawRect(
                        color = Color(0xFF4E342E),
                        topLeft = Offset(posX - hatBrimW * 0.5f, headCenterY - headRadius * 0.6f),
                        size = Size(hatBrimW, 5f * scale)
                    )
                    scope.drawRoundRect(
                        color = Color(0xFF5D4037),
                        topLeft = Offset(posX - hatBrimW * 0.35f, headCenterY - headRadius * 1.3f),
                        size = Size(hatBrimW * 0.7f, 12f * scale),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f * scale)
                    )
                }
                "maya" -> {
                    // Sleek Dark Hair with Jade Feather Crown
                    scope.drawCircle(
                        color = char.hairColor,
                        radius = headRadius * 0.95f,
                        center = Offset(posX, headCenterY - 4f * scale)
                    )
                    scope.drawCircle(
                        color = Color(0xFF00E676),
                        radius = 4f * scale,
                        center = Offset(posX + 8f * scale, headCenterY - headRadius * 0.8f)
                    )
                }
                "kage" -> {
                    // Midnight Shinobi Cowl with glowing eyes
                    scope.drawCircle(
                        color = Color(0xFF1E272C),
                        radius = headRadius * 1.05f,
                        center = Offset(posX, headCenterY)
                    )
                    // Glowing ninja visor slit
                    scope.drawRect(
                        color = Color(0xFFE040FB),
                        topLeft = Offset(posX - 8f * scale, headCenterY - 2f * scale),
                        size = Size(16f * scale, 3f * scale)
                    )
                }
                "solaris" -> {
                    // Sun Golem Bronze Crown & glowing eyes
                    scope.drawCircle(
                        color = Color(0xFFFFB300),
                        radius = headRadius * 0.9f,
                        center = Offset(posX, headCenterY - 3f * scale)
                    )
                    scope.drawCircle(
                        color = Color(0xFF00E5FF),
                        radius = 3.5f * scale,
                        center = Offset(posX - 4f * scale, headCenterY - 2f * scale)
                    )
                    scope.drawCircle(
                        color = Color(0xFF00E5FF),
                        radius = 3.5f * scale,
                        center = Offset(posX + 4f * scale, headCenterY - 2f * scale)
                    )
                }
            }

            // Draw Equipped Cosmetic Item
            drawCosmeticItem(scope, cosmetic, posX, headCenterY, scale, isSliding = false)
        }

        // Restore canvas transform
        scope.drawContext.canvas.restore()
    }

    private fun drawCosmeticItem(
        scope: DrawScope,
        cosmetic: CosmeticItem?,
        headX: Float,
        headY: Float,
        scale: Float,
        isSliding: Boolean
    ) {
        if (cosmetic == null) return

        when (cosmetic.id) {
            "sun_crown" -> {
                // Golden Aztec Crown with sun rays
                val crownW = 28f * scale
                val crownH = 14f * scale
                val crownY = headY - 14f * scale
                val path = Path().apply {
                    moveTo(headX - crownW * 0.5f, crownY + crownH)
                    lineTo(headX - crownW * 0.4f, crownY)
                    lineTo(headX - crownW * 0.15f, crownY + crownH * 0.5f)
                    lineTo(headX, crownY - 4f * scale)
                    lineTo(headX + crownW * 0.15f, crownY + crownH * 0.5f)
                    lineTo(headX + crownW * 0.4f, crownY)
                    lineTo(headX + crownW * 0.5f, crownY + crownH)
                    close()
                }
                scope.drawPath(path, Color(0xFFFFD54F))
                scope.drawCircle(
                    color = Color(0xFFFF6D00),
                    radius = 3f * scale,
                    center = Offset(headX, crownY + crownH * 0.6f)
                )
            }
            "aviator_scarf" -> {
                // Goggles on forehead + trailing crimson scarf
                // Goggles
                val gogW = 10f * scale
                scope.drawOval(
                    color = Color(0xFFFFB300),
                    topLeft = Offset(headX - 11f * scale, headY - 8f * scale),
                    size = Size(gogW, 6f * scale)
                )
                scope.drawOval(
                    color = Color(0xFFFFB300),
                    topLeft = Offset(headX + 1f * scale, headY - 8f * scale),
                    size = Size(gogW, 6f * scale)
                )
                // Flowing Scarf in wind
                val scarfTail = Path().apply {
                    moveTo(headX - 6f * scale, headY + 8f * scale)
                    lineTo(headX - 22f * scale, headY + 14f * scale)
                    lineTo(headX - 30f * scale, headY + 6f * scale)
                    lineTo(headX - 22f * scale, headY + 2f * scale)
                    close()
                }
                scope.drawPath(scarfTail, Color(0xFFD32F2F))
            }
            "oni_mask" -> {
                // Obsidian Oni Mask with horns
                scope.drawRoundRect(
                    color = Color(0xFF212121),
                    topLeft = Offset(headX - 10f * scale, headY - 6f * scale),
                    size = Size(20f * scale, 18f * scale),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f * scale)
                )
                // Cyan fangs / runes
                scope.drawCircle(
                    color = Color(0xFF00E5FF),
                    radius = 2.5f * scale,
                    center = Offset(headX - 4f * scale, headY - 2f * scale)
                )
                scope.drawCircle(
                    color = Color(0xFF00E5FF),
                    radius = 2.5f * scale,
                    center = Offset(headX + 4f * scale, headY - 2f * scale)
                )
            }
            "royal_cape" -> {
                // Flowing royal velvet cape behind player
                if (!isSliding) {
                    val capePath = Path().apply {
                        moveTo(headX - 14f * scale, headY + 12f * scale)
                        lineTo(headX - 24f * scale, headY + 54f * scale)
                        lineTo(headX + 24f * scale, headY + 54f * scale)
                        lineTo(headX + 14f * scale, headY + 12f * scale)
                        close()
                    }
                    scope.drawPath(capePath, Color(0xFF6A1B9A))
                    // Gold fringe border
                    scope.drawLine(
                        color = Color(0xFFFFD54F),
                        start = Offset(headX - 24f * scale, headY + 54f * scale),
                        end = Offset(headX + 24f * scale, headY + 54f * scale),
                        strokeWidth = 3f * scale
                    )
                }
            }
            "cyber_visor" -> {
                // Neon Cyan Holographic Visor
                scope.drawRoundRect(
                    color = Color(0xFF00E5FF),
                    topLeft = Offset(headX - 13f * scale, headY - 4f * scale),
                    size = Size(26f * scale, 7f * scale),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f * scale)
                )
                scope.drawCircle(
                    color = Color.White,
                    radius = 2f * scale,
                    center = Offset(headX + 5f * scale, headY)
                )
            }
        }
    }

    private fun drawPlayerAuras(
        scope: DrawScope,
        state: GameState,
        width: Float,
        height: Float
    ) {
        val player = state.player
        val charPoint = project(player.laneX, player.jumpY, 0.6f, width, height)
        val scale = charPoint.scale

        // Shield Bubble
        if (player.isShielded) {
            val shieldRadius = 55f * scale
            scope.drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x332979FF), Color(0x662979FF), Color(0xCC00E5FF)),
                    center = Offset(charPoint.x, charPoint.y - 35f * scale),
                    radius = shieldRadius
                ),
                radius = shieldRadius,
                center = Offset(charPoint.x, charPoint.y - 35f * scale),
                style = Stroke(width = 4f * scale)
            )
        }

        // Speed Rush Fire Trails
        if (player.isSpeedBoosting) {
            for (i in 0..4) {
                val trailY = charPoint.y - (i * 12f) * scale
                scope.drawCircle(
                    color = Color(0x88FF6D00),
                    radius = (20f - i * 3f) * scale,
                    center = Offset(charPoint.x, trailY)
                )
            }
        }

        // Magnet Aura
        if (player.isMagnetActive) {
            scope.drawCircle(
                color = Color(0x66FFEA00),
                radius = 48f * scale,
                center = Offset(charPoint.x, charPoint.y - 35f * scale),
                style = Stroke(width = 2.5f * scale)
            )
        }
    }

    private fun drawParticles(
        scope: DrawScope,
        particles: List<Particle>,
        width: Float,
        height: Float
    ) {
        val centerX = width * 0.5f
        val centerY = height * 0.72f

        for (p in particles) {
            scope.drawCircle(
                color = p.color.copy(alpha = p.alpha),
                radius = p.size,
                center = Offset(centerX + p.x, centerY + p.y)
            )
        }
    }

    private fun drawScorePopups(
        scope: DrawScope,
        popups: List<ScorePopup>,
        width: Float,
        height: Float
    ) {
        val centerX = width * 0.5f
        val centerY = height * 0.55f

        for (pop in popups) {
            scope.drawContext.canvas.nativeCanvas.apply {
                val paint = android.graphics.Paint().apply {
                    color = android.graphics.Color.argb(
                        (pop.alpha * 255).toInt(),
                        (pop.color.red * 255).toInt(),
                        (pop.color.green * 255).toInt(),
                        (pop.color.blue * 255).toInt()
                    )
                    textSize = 42f
                    isFakeBoldText = true
                    textAlign = android.graphics.Paint.Align.CENTER
                    setShadowLayer(8f, 0f, 0f, android.graphics.Color.BLACK)
                }
                drawText(pop.text, centerX + pop.x, centerY + pop.y, paint)
            }
        }
    }
}
