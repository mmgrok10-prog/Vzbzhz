package com.example

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.data.GamePreferences
import com.example.game.GameEngine
import com.example.game.GameStatus
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

enum class Screen {
    MAIN_MENU,
    GAME,
    CUSTOMIZER,
    UPGRADES,
    STATS
}

class MainActivity : ComponentActivity() {

    private lateinit var preferences: GamePreferences
    private lateinit var gameEngine: GameEngine
    private var vibrator: Vibrator? = null

    // For keyboard shortcuts
    private var onKeyDownListener: ((keyCode: Int) -> Boolean)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        preferences = GamePreferences(applicationContext)
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

        gameEngine = GameEngine(
            preferences = preferences,
            onHapticFeedback = { type ->
                triggerHaptic(type)
            }
        )

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TempleRunnerApp(
                        preferences = preferences,
                        gameEngine = gameEngine,
                        setKeyListener = { listener ->
                            onKeyDownListener = listener
                        }
                    )
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (onKeyDownListener?.invoke(keyCode) == true) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun triggerHaptic(type: String) {
        if (!preferences.vibrationEnabled.value) return
        val vib = vibrator ?: return
        if (!vib.hasVibrator()) return

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = when (type) {
                    "coin" -> VibrationEffect.createOneShot(12, 100)
                    "lane" -> VibrationEffect.createOneShot(18, 120)
                    "jump" -> VibrationEffect.createOneShot(24, 150)
                    "slide" -> VibrationEffect.createOneShot(20, 140)
                    "powerup" -> VibrationEffect.createOneShot(45, 200)
                    "stumble" -> VibrationEffect.createWaveform(longArrayOf(0, 30, 40, 50), -1)
                    "smash" -> VibrationEffect.createOneShot(50, 220)
                    "game_over" -> VibrationEffect.createWaveform(longArrayOf(0, 60, 60, 90), -1)
                    else -> VibrationEffect.createOneShot(15, 100)
                }
                vib.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(25)
            }
        } catch (_: Exception) {
            // Graceful fallback
        }
    }
}

@Composable
fun TempleRunnerApp(
    preferences: GamePreferences,
    gameEngine: GameEngine,
    setKeyListener: ((keyCode: Int) -> Boolean) -> Unit
) {
    var currentScreen by remember { mutableStateOf(Screen.MAIN_MENU) }
    val gameState by gameEngine.gameState.collectAsState()

    // Register keyboard listener
    DisposableEffect(currentScreen, gameState.status) {
        setKeyListener { keyCode ->
            if (currentScreen == Screen.GAME && gameState.status == GameStatus.RUNNING) {
                when (keyCode) {
                    KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_DPAD_LEFT -> {
                        gameEngine.moveLeft()
                        true
                    }
                    KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        gameEngine.moveRight()
                        true
                    }
                    KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_SPACE -> {
                        gameEngine.jump()
                        true
                    }
                    KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_DPAD_DOWN -> {
                        gameEngine.slide()
                        true
                    }
                    KeyEvent.KEYCODE_P, KeyEvent.KEYCODE_ESCAPE -> {
                        gameEngine.pauseGame()
                        true
                    }
                    else -> false
                }
            } else false
        }
        onDispose {
            setKeyListener { false }
        }
    }

    // Back handling
    BackHandler(enabled = currentScreen != Screen.MAIN_MENU) {
        when (currentScreen) {
            Screen.GAME -> {
                if (gameState.status == GameStatus.RUNNING) {
                    gameEngine.pauseGame()
                } else {
                    currentScreen = Screen.MAIN_MENU
                }
            }
            Screen.CUSTOMIZER -> {
                gameEngine.refreshEquippedItems()
                currentScreen = Screen.MAIN_MENU
            }
            Screen.UPGRADES -> currentScreen = Screen.MAIN_MENU
            Screen.STATS -> currentScreen = Screen.MAIN_MENU
            Screen.MAIN_MENU -> {}
        }
    }

    when (currentScreen) {
        Screen.MAIN_MENU -> {
            MainMenuScreen(
                preferences = preferences,
                onStartGame = {
                    gameEngine.startNewGame()
                    currentScreen = Screen.GAME
                },
                onOpenCustomizer = {
                    currentScreen = Screen.CUSTOMIZER
                },
                onOpenUpgrades = {
                    currentScreen = Screen.UPGRADES
                },
                onOpenStats = {
                    currentScreen = Screen.STATS
                }
            )
        }

        Screen.GAME -> {
            GameScreen(
                engine = gameEngine,
                preferences = preferences,
                onOpenCustomizer = {
                    currentScreen = Screen.CUSTOMIZER
                },
                onReturnToMainMenu = {
                    currentScreen = Screen.MAIN_MENU
                }
            )
        }

        Screen.CUSTOMIZER -> {
            CharacterCustomizationScreen(
                preferences = preferences,
                onBack = {
                    gameEngine.refreshEquippedItems()
                    currentScreen = Screen.MAIN_MENU
                }
            )
        }

        Screen.UPGRADES -> {
            UpgradesScreen(
                preferences = preferences,
                onBack = {
                    currentScreen = Screen.MAIN_MENU
                }
            )
        }

        Screen.STATS -> {
            StatsScreen(
                preferences = preferences,
                onBack = {
                    currentScreen = Screen.MAIN_MENU
                }
            )
        }
    }
}
