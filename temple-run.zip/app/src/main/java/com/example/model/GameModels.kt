package com.example.model

import androidx.compose.ui.graphics.Color

enum class Lane(val index: Int) {
    LEFT(-1),
    CENTER(0),
    RIGHT(1);

    fun moveLeft(): Lane = when (this) {
        RIGHT -> CENTER
        CENTER -> LEFT
        LEFT -> LEFT
    }

    fun moveRight(): Lane = when (this) {
        LEFT -> CENTER
        CENTER -> RIGHT
        RIGHT -> RIGHT
    }
}

enum class ObstacleRequirement {
    JUMP,
    SLIDE,
    DODGE
}

enum class ObstacleType(
    val displayName: String,
    val requirement: ObstacleRequirement,
    val heightRatio: Float,
    val color: Color
) {
    TREE_LOG("Fallen Jungle Log", ObstacleRequirement.JUMP, 0.35f, Color(0xFF6D4C41)),
    FIRE_PIT("Ancient Flame Brazier", ObstacleRequirement.JUMP, 0.4f, Color(0xFFFF5722)),
    SPIKE_TRAP("Temple Floor Spikes", ObstacleRequirement.JUMP, 0.3f, Color(0xFF9E9E9E)),
    TEMPLE_ARCH("Low Stone Archway", ObstacleRequirement.SLIDE, 0.9f, Color(0xFF4E342E)),
    BLADE_PENDULUM("Swinging Temple Blade", ObstacleRequirement.SLIDE, 0.85f, Color(0xFFB0BEC5)),
    CRUMBLING_PILLAR("Crumbling Stone Monolith", ObstacleRequirement.DODGE, 1.2f, Color(0xFF37474F)),
    STONE_BLOCK("Collapsed Altar", ObstacleRequirement.DODGE, 1.0f, Color(0xFF455A64))
}

data class Obstacle(
    val id: Long,
    val lane: Lane,
    var z: Float, // distance ahead of player in meters
    val type: ObstacleType,
    var cleared: Boolean = false,
    var hit: Boolean = false
)

enum class CollectibleType(
    val displayName: String,
    val scoreValue: Int,
    val coinValue: Int,
    val color: Color
) {
    COIN("Temple Gold", 10, 1, Color(0xFFFFD54F)),
    EMERALD("Relic Gem", 50, 5, Color(0xFF00E676)),
    MAGNET("Coin Magnet", 100, 0, Color(0xFFFFEA00)),
    SHIELD("Solar Shield", 100, 0, Color(0xFF2979FF)),
    SPEED_BOOST("Relic Rush", 200, 0, Color(0xFFFF6D00)),
    MULTIPLIER_2X("2x Multiplier", 150, 0, Color(0xFFB388FF))
}

data class Collectible(
    val id: Long,
    val lane: Lane,
    var z: Float,
    val yHeight: Float, // 0 = ground, 1.0 = jumping height
    val type: CollectibleType,
    var collected: Boolean = false
)

enum class PowerUpType(val durationSeconds: Float, val title: String, val color: Color) {
    MAGNET(10f, "MAGNET", Color(0xFFFFEA00)),
    SHIELD(12f, "SHIELD", Color(0xFF2979FF)),
    SPEED_BOOST(7f, "RUSH!", Color(0xFFFF6D00)),
    MULTIPLIER_2X(12f, "2X SCORE", Color(0xFFB388FF))
}

data class ActivePowerUp(
    val type: PowerUpType,
    var remainingTime: Float,
    val totalTime: Float
)

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var color: Color,
    var alpha: Float,
    var size: Float,
    var life: Float,
    val maxLife: Float
)

data class ScorePopup(
    val id: Long,
    val text: String,
    val color: Color,
    var x: Float,
    var y: Float,
    var alpha: Float = 1.0f,
    var life: Float = 1.0f
)

data class Torch(
    val z: Float,
    val isLeft: Boolean,
    var flameFlicker: Float = 1.0f
)
