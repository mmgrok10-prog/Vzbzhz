package com.example.model

import androidx.compose.ui.graphics.Color

data class GameCharacter(
    val id: String,
    val name: String,
    val title: String,
    val bio: String,
    val unlockCost: Int, // 0 means base character
    val perkName: String,
    val perkDescription: String,
    // Visual appearance parameters for custom 2.5D renderer
    val skinColor: Color,
    val hairColor: Color,
    val shirtColor: Color,
    val pantsColor: Color,
    val accentColor: Color,
    val isMechanicalOrDemon: Boolean = false,
    val eyeGlowColor: Color = Color.Transparent
)

object CharacterCatalog {
    val BASE_CHARACTER = GameCharacter(
        id = "harrison",
        name = "Harrison Dare",
        title = "Rugged Explorer",
        bio = "A daring archaeologist who lives for ancient ruins, ancient traps, and golden relics.",
        unlockCost = 0,
        perkName = "Lucky Discovery",
        perkDescription = "Extra +15% coin spawns along temple tracks",
        skinColor = Color(0xFFD7A780),
        hairColor = Color(0xFF5D4037),
        shirtColor = Color(0xFF8D6E63), // Brown explorer jacket
        pantsColor = Color(0xFF4E342E), // Khaki adventuring trousers
        accentColor = Color(0xFFFFD54F)  // Gold buckle & fedora band
    )

    val UNLOCKABLE_1 = GameCharacter(
        id = "maya",
        name = "Maya Swift",
        title = "Temple Acrobat",
        bio = "An agile ruins runner trained in ancient jungle parkour and lightning-fast dodges.",
        unlockCost = 500,
        perkName = "Acrobatic Reflexes",
        perkDescription = "+20% jump hangtime and 25% faster slide recovery",
        skinColor = Color(0xFFC68642),
        hairColor = Color(0xFF212121),
        shirtColor = Color(0xFF00897B), // Jade ceremonial tunic
        pantsColor = Color(0xFF004D40), // Dark teal runner leggings
        accentColor = Color(0xFF80CBC4)  // Jade feather accents
    )

    val UNLOCKABLE_2 = GameCharacter(
        id = "kage",
        name = "Shadow Ronin (Kage)",
        title = "Midnight Shinobi",
        bio = "A master of shadows who moves unseen through the crumbling corridors of the forbidden temple.",
        unlockCost = 1200,
        perkName = "Shadow Magnetism",
        perkDescription = "+50% coin magnet collection range and +3s powerup duration",
        skinColor = Color(0xFFE0BB9B),
        hairColor = Color(0xFF1A1A1A),
        shirtColor = Color(0xFF263238), // Midnight stealth shinobi shroud
        pantsColor = Color(0xFF102027), // Deep shadow pants
        accentColor = Color(0xFFE53935), // Crimson shinobi sash & dual scabbards
        eyeGlowColor = Color(0xFFE040FB)
    )

    val UNLOCKABLE_3 = GameCharacter(
        id = "solaris",
        name = "Sun Golem (Solaris)",
        title = "Ancient Sun Idol",
        bio = "An animated Aztec monolith forged from sun-bronze and powered by an eternal solar heart.",
        unlockCost = 2500,
        perkName = "Solar Aegis",
        perkDescription = "Survives 1 fatal obstacle crash per run with an automatic shield burst",
        skinColor = Color(0xFFB08D57), // Ancient bronze stone
        hairColor = Color(0xFFFFB300), // Carved solar crest
        shirtColor = Color(0xFF8C6D38), // Stone torso with glowing runes
        pantsColor = Color(0xFF5A4421), // Heavy stone limbs
        accentColor = Color(0xFFFF6D00), // Glowing lava runes
        isMechanicalOrDemon = true,
        eyeGlowColor = Color(0xFF00E5FF)  // Glowing cyan crystal eyes
    )

    val ALL_CHARACTERS = listOf(BASE_CHARACTER, UNLOCKABLE_1, UNLOCKABLE_2, UNLOCKABLE_3)

    fun getById(id: String): GameCharacter {
        return ALL_CHARACTERS.find { it.id == id } ?: BASE_CHARACTER
    }
}
