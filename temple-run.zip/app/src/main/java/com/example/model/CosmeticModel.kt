package com.example.model

import androidx.compose.ui.graphics.Color

enum class CosmeticSlot(val displayName: String) {
    HEADWEAR("Headwear"),
    SCARF("Neckwear"),
    MASK("Face Mask"),
    CAPE("Back Outfit"),
    VISOR("Tech Gear")
}

data class CosmeticItem(
    val id: String,
    val name: String,
    val slot: CosmeticSlot,
    val price: Int,
    val description: String,
    val visualEffect: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val iconSymbol: String
)

object CosmeticCatalog {
    val SUN_CROWN = CosmeticItem(
        id = "sun_crown",
        name = "Sun God Crown",
        slot = CosmeticSlot.HEADWEAR,
        price = 300,
        description = "A sacred Aztec feathered crown forged from ancient radiant gold.",
        visualEffect = "Radiates solar golden spark trails around character",
        primaryColor = Color(0xFFFFD54F),
        secondaryColor = Color(0xFFFF8F00),
        iconSymbol = "👑"
    )

    val AVIATOR_SCARF = CosmeticItem(
        id = "aviator_scarf",
        name = "Aviator Goggles & Scarf",
        slot = CosmeticSlot.SCARF,
        price = 450,
        description = "Polished brass explorer goggles paired with a long crimson silk scarf.",
        visualEffect = "Scarf billows dynamically in wind during sprint & jumps",
        primaryColor = Color(0xFFD32F2F),
        secondaryColor = Color(0xFFFFB300),
        iconSymbol = "🧣"
    )

    val ONI_MASK = CosmeticItem(
        id = "oni_mask",
        name = "Obsidian Oni Mask",
        slot = CosmeticSlot.MASK,
        price = 800,
        description = "A fearsome ceremonial mask carved from volcanic glass with golden horn spikes.",
        visualEffect = "Emits cyan spirit flame wisps while sliding and sprinting",
        primaryColor = Color(0xFF212121),
        secondaryColor = Color(0xFF00E5FF),
        iconSymbol = "👺"
    )

    val ROYAL_CAPE = CosmeticItem(
        id = "royal_cape",
        name = "Royal Explorer Cape",
        slot = CosmeticSlot.CAPE,
        price = 1000,
        description = "A magnificent velvet cape lined with gold Aztec sun glyph embroidery.",
        visualEffect = "Expands into an imposing royal mantle during high jumps",
        primaryColor = Color(0xFF6A1B9A),
        secondaryColor = Color(0xFFFFD54F),
        iconSymbol = "🦸"
    )

    val CYBER_VISOR = CosmeticItem(
        id = "cyber_visor",
        name = "Cyber Neon Visor",
        slot = CosmeticSlot.VISOR,
        price = 1500,
        description = "Holographic energy visor scanning ancient runes with digital pulse grids.",
        visualEffect = "Creates neon matrix pulse bursts when jumping or collecting relics",
        primaryColor = Color(0xFF00E5FF),
        secondaryColor = Color(0xFF76FF03),
        iconSymbol = "🥽"
    )

    val ALL_COSMETICS = listOf(
        SUN_CROWN,
        AVIATOR_SCARF,
        ONI_MASK,
        ROYAL_CAPE,
        CYBER_VISOR
    )

    fun getById(id: String?): CosmeticItem? {
        if (id == null) return null
        return ALL_COSMETICS.find { it.id == id }
    }
}
