package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.game.GameState
import com.example.ui.theme.*

@Composable
fun GameOverDialog(
    state: GameState,
    highScore: Int,
    coinsBalance: Int,
    onRevive: () -> Unit,
    onPlayAgain: () -> Unit,
    onOpenCustomizer: () -> Unit,
    onMainMenu: () -> Unit
) {
    val isNewHighScore = state.score > highScore

    Dialog(onDismissRequest = {}) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(2.dp, DemonFlameRed, RoundedCornerShape(16.dp))
                .testTag("game_over_dialog"),
            colors = CardDefaults.cardColors(
                containerColor = AncientStoneMedium
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "TEMPLE CRASH!",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = DemonFlameRed,
                    textAlign = TextAlign.Center
                )

                if (state.deathReason.isNotEmpty()) {
                    Text(
                        text = state.deathReason,
                        fontSize = 13.sp,
                        color = TextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )
                }

                if (isNewHighScore) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = TempleGold.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TempleGold),
                        modifier = Modifier.padding(bottom = 12.dp)
                    ) {
                        Text(
                            text = "🏆 NEW HIGH SCORE! 🏆",
                            color = TempleGold,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                // Stats Grid
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AncientStoneDark,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        StatRow(title = "Final Score", value = "${state.score}")
                        StatRow(title = "Distance", value = "${state.distanceMeters.toInt()} meters")
                        StatRow(title = "Coins Collected", value = "+${state.coinsThisRun} 🪙")
                        StatRow(title = "Relic Gems", value = "+${state.gemsThisRun} 💎")
                        Divider(
                            color = AncientStoneBorder,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                        StatRow(
                            title = "High Score",
                            value = "${if (isNewHighScore) state.score else highScore}",
                            isHighlight = true
                        )
                        StatRow(
                            title = "Total Wallet",
                            value = "$coinsBalance 🪙"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Revive Option (if player has at least 100 coins)
                if (coinsBalance >= 100) {
                    Button(
                        onClick = onRevive,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = JungleEmerald,
                            contentColor = AncientStoneDark
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("revive_button")
                    ) {
                        Text(
                            text = "REVIVE (100 🪙)",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Play Again Button
                Button(
                    onClick = onPlayAgain,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TempleGold,
                        contentColor = AncientStoneDark
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("play_again_button")
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Retry")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "RUN AGAIN",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = onOpenCustomizer,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("game_over_wardrobe_button"),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = TempleGold
                        )
                    ) {
                        Text("WARDROBE", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedButton(
                        onClick = onMainMenu,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("game_over_menu_button"),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = TextGold
                        )
                    ) {
                        Text("MENU", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun PauseDialog(
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onOpenCustomizer: () -> Unit,
    onMainMenu: () -> Unit
) {
    Dialog(onDismissRequest = onResume) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(2.dp, TempleGold, RoundedCornerShape(16.dp))
                .testTag("pause_dialog"),
            colors = CardDefaults.cardColors(
                containerColor = AncientStoneMedium
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "EXPEDITION PAUSED",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TempleGold
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onResume,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TempleGold,
                        contentColor = AncientStoneDark
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pause_resume_button")
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Resume")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("RESUME", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                FilledTonalButton(
                    onClick = onRestart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pause_restart_button")
                ) {
                    Text("RESTART RUN", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onOpenCustomizer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pause_wardrobe_button"),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = TempleGold
                    )
                ) {
                    Text("WARDROBE & HEROES")
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(
                    onClick = onMainMenu,
                    modifier = Modifier.testTag("pause_main_menu_button")
                ) {
                    Text("QUIT TO MAIN MENU", color = TextMuted)
                }
            }
        }
    }
}

@Composable
private fun StatRow(
    title: String,
    value: String,
    isHighlight: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            color = if (isHighlight) TempleGold else TextMuted,
            fontSize = 13.sp,
            fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = value,
            color = if (isHighlight) TempleGold else TextGold,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
