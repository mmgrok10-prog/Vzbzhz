package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Temple Run Palette: Gold, Ancient Stone, Jungle Moss, Fire & Obsidian
val TempleGold = Color(0xFFFFD54F)
val TempleGoldDark = Color(0xFFFF8F00)
val TempleAmber = Color(0xFFFFB300)
val TempleBronze = Color(0xFFD7CCC8)

val AncientStoneDark = Color(0xFF1E1712)
val AncientStoneMedium = Color(0xFF2C221A)
val AncientStoneSurface = Color(0xFF3E3125)
val AncientStoneBorder = Color(0xFF5D4A3A)

val JungleEmerald = Color(0xFF00E676)
val GemCyan = Color(0xFF00E5FF)
val DemonFlameRed = Color(0xFFFF3D00)
val DemonPurple = Color(0xFFB388FF)

val TextGold = Color(0xFFFFF8E1)
val TextMuted = Color(0xFFBCAAA4)
val ShieldBlue = Color(0xFF2979FF)
val MagnetYellow = Color(0xFFFFEA00)
val BoostOrange = Color(0xFFFF6D00)
