package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TempleColorScheme = darkColorScheme(
    primary = TempleGold,
    onPrimary = Color(0xFF241500),
    primaryContainer = TempleGoldDark,
    onPrimaryContainer = Color(0xFFFFF8E1),
    secondary = JungleEmerald,
    onSecondary = Color(0xFF003915),
    secondaryContainer = Color(0xFF004D40),
    onSecondaryContainer = Color(0xFFA7F3D0),
    tertiary = GemCyan,
    onTertiary = Color(0xFF00363D),
    background = AncientStoneDark,
    onBackground = TextGold,
    surface = AncientStoneMedium,
    onSurface = TextGold,
    surfaceVariant = AncientStoneSurface,
    onSurfaceVariant = TextMuted,
    error = DemonFlameRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TempleColorScheme,
        typography = Typography,
        content = content
    )
}
