package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GamePreferences
import com.example.game.GameEngine
import com.example.game.GameStatus
import com.example.game.Renderer3D
import com.example.model.PowerUpType
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.abs

/**
 * Custom Compose Gesture Modifier for low-latency, fluid Swipe-To-Dodge mechanics.
 * Detects Left, Right, Jump (Up), and Slide (Down) with flick velocity, displacement
 * tracking, chaining support, and tactile touch path recording.
 */
fun Modifier.swipeToDodge(
    enabled: Boolean,
    swipeThresholdPx: Float,
    onSwipeLeft: () -> Unit,
    onSwipeRight: () -> Unit,
    onSwipeUp: () -> Unit,
    onSwipeDown: () -> Unit,
    onSwipeTrailUpdate: (List<Offset>) -> Unit,
    onSwipeActionRecognized: (actionText: String, color: Color) -> Unit
): Modifier = pointerInput(enabled) {
    if (!enabled) return@pointerInput

    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        var startPos = down.position
        var currentPos = down.position
        val trailPoints = mutableListOf(down.position)
        var hasTriggeredAction = false

        onSwipeTrailUpdate(trailPoints.toList())

        do {
            val event = awaitPointerEvent()
            val change = event.changes.firstOrNull { it.id == down.id } ?: break

            if (change.pressed) {
                currentPos = change.position
                trailPoints.add(currentPos)
                if (trailPoints.size > 14) trailPoints.removeAt(0)
                onSwipeTrailUpdate(trailPoints.toList())

                val dx = currentPos.x - startPos.x
                val dy = currentPos.y - startPos.y
                val absX = abs(dx)
                val absY = abs(dy)

                if (!hasTriggeredAction) {
                    if (absX >= swipeThresholdPx || absY >= swipeThresholdPx) {
                        if (absX > absY) {
                            if (dx < -swipeThresholdPx) {
                                onSwipeLeft()
                                onSwipeActionRecognized("◀ DODGE LEFT", Color(0xFFFFD54F))
                                hasTriggeredAction = true
                                startPos = currentPos
                            } else if (dx > swipeThresholdPx) {
                                onSwipeRight()
                                onSwipeActionRecognized("DODGE RIGHT ▶", Color(0xFFFFD54F))
                                hasTriggeredAction = true
                                startPos = currentPos
                            }
                        } else {
                            if (dy < -swipeThresholdPx) {
                                onSwipeUp()
                                onSwipeActionRecognized("▲ JUMP", Color(0xFF00E676))
                                hasTriggeredAction = true
                                startPos = currentPos
                            } else if (dy > swipeThresholdPx) {
                                onSwipeDown()
                                onSwipeActionRecognized("▼ SLIDE", Color(0xFF00E5FF))
                                hasTriggeredAction = true
                                startPos = currentPos
                            }
                        }
                        change.consume()
                    }
                } else {
                    // Chained gesture detection (e.g. swiped right to change lane, then immediately flicked up to jump!)
                    if (absX >= swipeThresholdPx || absY >= swipeThresholdPx) {
                        if (absX > absY) {
                            if (dx < -swipeThresholdPx) {
                                onSwipeLeft()
                                onSwipeActionRecognized("◀ DODGE LEFT", Color(0xFFFFD54F))
                                startPos = currentPos
                            } else if (dx > swipeThresholdPx) {
                                onSwipeRight()
                                onSwipeActionRecognized("DODGE RIGHT ▶", Color(0xFFFFD54F))
                                startPos = currentPos
                            }
                        } else {
                            if (dy < -swipeThresholdPx) {
                                onSwipeUp()
                                onSwipeActionRecognized("▲ JUMP", Color(0xFF00E676))
                                startPos = currentPos
                            } else if (dy > swipeThresholdPx) {
                                onSwipeDown()
                                onSwipeActionRecognized("▼ SLIDE", Color(0xFF00E5FF))
                                startPos = currentPos
                            }
                        }
                        change.consume()
                    }
                }
            }
        } while (event.changes.any { it.pressed })

        onSwipeTrailUpdate(emptyList())
    }
}

@Composable
fun GameScreen(
    engine: GameEngine,
    preferences: GamePreferences,
    onOpenCustomizer: () -> Unit,
    onReturnToMainMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by engine.gameState.collectAsState()
    val highScore by preferences.highScore.collectAsState()
    val coinsBalance by preferences.coins.collectAsState()
    val arcadeControls by preferences.arcadeControlsEnabled.collectAsState()

    // 60 FPS Game Loop
    LaunchedEffect(state.status) {
        if (state.status == GameStatus.RUNNING) {
            var lastTime = System.nanoTime()
            while (true) {
                withFrameNanos { now ->
                    val dt = ((now - lastTime) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                    lastTime = now
                    engine.update(dt)
                }
            }
        }
    }

    val density = LocalDensity.current
    val swipeThresholdPx = with(density) { 32.dp.toPx() }

    var swipeTrailPoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var activeActionText by remember { mutableStateOf<String?>(null) }
    var activeActionColor by remember { mutableStateOf(TempleGold) }

    // Auto-dismiss floating action feedback
    LaunchedEffect(activeActionText) {
        if (activeActionText != null) {
            delay(650)
            activeActionText = null
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .swipeToDodge(
                enabled = state.status == GameStatus.RUNNING,
                swipeThresholdPx = swipeThresholdPx,
                onSwipeLeft = { engine.moveLeft() },
                onSwipeRight = { engine.moveRight() },
                onSwipeUp = { engine.jump() },
                onSwipeDown = { engine.slide() },
                onSwipeTrailUpdate = { points -> swipeTrailPoints = points },
                onSwipeActionRecognized = { text, color ->
                    activeActionText = text
                    activeActionColor = color
                }
            )
            .testTag("game_screen_root")
    ) {
        // 1. 3D GAME CANVAS
        Canvas(modifier = Modifier.fillMaxSize()) {
            Renderer3D.render(this, state, size.width, size.height)

            // Dynamic Touch Swipe Trail Overlay
            if (swipeTrailPoints.size >= 2) {
                val trailPath = Path().apply {
                    moveTo(swipeTrailPoints.first().x, swipeTrailPoints.first().y)
                    for (i in 1 until swipeTrailPoints.size) {
                        lineTo(swipeTrailPoints[i].x, swipeTrailPoints[i].y)
                    }
                }
                // Glowing outer streak
                drawPath(
                    path = trailPath,
                    brush = Brush.linearGradient(
                        colors = listOf(Color(0x33FFD54F), Color(0xAA00E5FF), Color(0xFFFFD54F)),
                        start = swipeTrailPoints.first(),
                        end = swipeTrailPoints.last()
                    ),
                    style = Stroke(width = 8f, cap = StrokeCap.Round)
                )
                // Crisp core streak
                drawPath(
                    path = trailPath,
                    color = Color.White.copy(alpha = 0.85f),
                    style = Stroke(width = 3f, cap = StrokeCap.Round)
                )
                // Tip ember spark
                drawCircle(
                    color = activeActionColor,
                    radius = 7f,
                    center = swipeTrailPoints.last()
                )
            }
        }

        // 2. FLOATING ACTION RECOGNITION PILL
        AnimatedVisibility(
            visible = activeActionText != null,
            enter = fadeIn() + scaleIn(initialScale = 0.85f),
            exit = fadeOut() + scaleOut(targetScale = 0.95f),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 92.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = AncientStoneDark.copy(alpha = 0.88f),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, activeActionColor)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = activeActionText ?: "",
                        color = activeActionColor,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // 3. IN-GAME TOP HUD
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Score & Multiplier
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AncientStoneDark.copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AncientStoneBorder)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Column {
                            Text(
                                text = "SCORE",
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${state.score}",
                                color = TextGold,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                        if (state.multiplier > 1) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = TempleGoldDark
                            ) {
                                Text(
                                    text = "${state.multiplier}X",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                // Coins & Distance Meters
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AncientStoneDark.copy(alpha = 0.85f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TempleGold)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("🪙", fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${state.coinsThisRun}",
                                color = TempleGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "${state.distanceMeters.toInt()}m",
                                color = TextGold,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Pause Button
                    IconButton(
                        onClick = { engine.pauseGame() },
                        modifier = Modifier
                            .size(40.dp)
                            .background(AncientStoneDark.copy(alpha = 0.85f), CircleShape)
                            .border(1.dp, AncientStoneBorder, CircleShape)
                            .testTag("game_pause_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pause,
                            contentDescription = "Pause",
                            tint = TextGold,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Power-Up Active Chips
            if (state.activePowerUps.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    horizontalArrangement = Arrangement.Start
                ) {
                    for (power in state.activePowerUps) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = power.type.color.copy(alpha = 0.25f),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, power.type.color),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = when (power.type) {
                                        PowerUpType.MAGNET -> "🧲"
                                        PowerUpType.SHIELD -> "🛡️"
                                        PowerUpType.SPEED_BOOST -> "⚡"
                                        PowerUpType.MULTIPLIER_2X -> "✨"
                                    },
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${power.remainingTime.toInt()}s",
                                    color = power.type.color,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            // Beast Danger Warning Bar
            if (state.beastDistance < 7f) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DemonFlameRed.copy(alpha = 0.85f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 4.dp, horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text("👹", fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "BEAST IS CLOSE! DON'T STUMBLE!",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // 4. OPTIONAL ON-SCREEN ARCADE CONTROLS
        if (arcadeControls && state.status == GameStatus.RUNNING) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 24.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    // Left / Right Lane Arrows
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ArcadeButton(
                            symbol = "◀",
                            description = "Move Left",
                            onClick = { engine.moveLeft() },
                            tag = "arcade_btn_left"
                        )
                        ArcadeButton(
                            symbol = "▶",
                            description = "Move Right",
                            onClick = { engine.moveRight() },
                            tag = "arcade_btn_right"
                        )
                    }

                    // Jump & Slide Action Buttons
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ArcadeButton(
                            symbol = "▲ JUMP",
                            description = "Jump",
                            onClick = { engine.jump() },
                            color = TempleGold,
                            tag = "arcade_btn_jump"
                        )
                        ArcadeButton(
                            symbol = "▼ SLIDE",
                            description = "Slide",
                            onClick = { engine.slide() },
                            color = GemCyan,
                            tag = "arcade_btn_slide"
                        )
                    }
                }
            }
        }

        // 5. DIALOGS
        if (state.status == GameStatus.PAUSED) {
            PauseDialog(
                onResume = { engine.resumeGame() },
                onRestart = { engine.startNewGame() },
                onOpenCustomizer = onOpenCustomizer,
                onMainMenu = onReturnToMainMenu
            )
        }

        if (state.status == GameStatus.GAME_OVER) {
            GameOverDialog(
                state = state,
                highScore = highScore,
                coinsBalance = coinsBalance,
                onRevive = { engine.reviveGame() },
                onPlayAgain = { engine.startNewGame() },
                onOpenCustomizer = onOpenCustomizer,
                onMainMenu = onReturnToMainMenu
            )
        }
    }
}

@Composable
private fun ArcadeButton(
    symbol: String,
    description: String,
    onClick: () -> Unit,
    color: Color = TextGold,
    tag: String
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = AncientStoneDark.copy(alpha = 0.75f),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, color.copy(alpha = 0.7f)),
        modifier = Modifier
            .height(52.dp)
            .widthIn(min = 58.dp)
            .testTag(tag)
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = symbol,
                color = color,
                fontWeight = FontWeight.Black,
                fontSize = 14.sp
            )
        }
    }
}
