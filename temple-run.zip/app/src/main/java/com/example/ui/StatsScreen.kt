package com.example.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GamePreferences
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(
    preferences: GamePreferences,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val highScore by preferences.highScore.collectAsState()
    val totalRuns by preferences.totalRuns.collectAsState()
    val totalDistance by preferences.totalDistance.collectAsState()
    val coins by preferences.coins.collectAsState()
    val unlockedChars by preferences.unlockedCharacters.collectAsState()
    val unlockedCosmetics by preferences.unlockedCosmetics.collectAsState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Temple Records & Guide",
                        fontWeight = FontWeight.Bold,
                        color = TempleGold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("stats_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TempleGold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AncientStoneDark
                )
            )
        },
        containerColor = AncientStoneDark
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Lifetime Stats Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, TempleGold, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = AncientStoneMedium),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "LIFETIME EXPEDITIONS",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            color = TempleGold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        RecordItem("Best Run Score", "$highScore PTS", isGold = true)
                        RecordItem("Total Expeditions", "$totalRuns RUNS")
                        RecordItem("Total Distance Run", "${totalDistance.toInt()} METERS")
                        RecordItem("Wallet Gold", "$coins 🪙")
                        RecordItem("Heroes Unlocked", "${unlockedChars.size} / 4")
                        RecordItem("Cosmetics Owned", "${unlockedCosmetics.size} / 5")
                    }
                }
            }

            // How To Play Guide Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AncientStoneBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = AncientStoneMedium),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "HOW TO ESCAPE THE TEMPLE",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            color = TextGold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        GuideRow("↔️ Swipe Left / Right", "Switch between the 3 stone lanes.")
                        GuideRow("⬆️ Swipe Up", "Leap over fallen logs, spike pits, and flame braziers.")
                        GuideRow("⬇️ Swipe Down", "Duck and slide under low stone archways & pendulum blades.")
                        GuideRow("👹 The Demon Beast", "If you stumble, the beast roars closer! Run cleanly to gain distance.")
                        GuideRow("🎛️ Keyboard & Buttons", "Use A/D or Arrow keys, W/Space to jump, S to slide, or on-screen controls.")
                    }
                }
            }
        }
    }
}

@Composable
private fun RecordItem(title: String, value: String, isGold: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = title, color = TextMuted, fontSize = 13.sp)
        Text(
            text = value,
            fontWeight = FontWeight.Bold,
            color = if (isGold) TempleGold else TextGold,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun GuideRow(title: String, desc: String) {
    Column(modifier = Modifier.padding(vertical = 5.dp)) {
        Text(
            text = title,
            fontWeight = FontWeight.Bold,
            color = TempleAmber,
            fontSize = 13.sp
        )
        Text(
            text = desc,
            color = TextMuted,
            fontSize = 12.sp
        )
    }
}
