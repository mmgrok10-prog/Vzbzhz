package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GamePreferences
import com.example.game.GameState
import com.example.game.PlayerVisualState
import com.example.game.Renderer3D
import com.example.model.CharacterCatalog
import com.example.model.CosmeticCatalog
import com.example.ui.theme.*

@Composable
fun MainMenuScreen(
    preferences: GamePreferences,
    onStartGame: () -> Unit,
    onOpenCustomizer: () -> Unit,
    onOpenUpgrades: () -> Unit,
    onOpenStats: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coins by preferences.coins.collectAsState()
    val highScore by preferences.highScore.collectAsState()
    val equippedCharId by preferences.equippedCharacterId.collectAsState()
    val equippedCosmeticId by preferences.equippedCosmeticId.collectAsState()
    val arcadeControls by preferences.arcadeControlsEnabled.collectAsState()
    val vibrationEnabled by preferences.vibrationEnabled.collectAsState()

    val equippedCharacter = CharacterCatalog.getById(equippedCharId)
    val equippedCosmetic = CosmeticCatalog.getById(equippedCosmeticId)

    var runCycle by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var lastTime = System.nanoTime()
        while (true) {
            withFrameNanos { now ->
                val dt = ((now - lastTime) / 1_000_000_000f).coerceIn(0f, 0.05f)
                lastTime = now
                runCycle = (runCycle + dt * 2.2f) % 1.0f
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0C1612), // Deep jungle night
                        AncientStoneDark,
                        AncientStoneMedium
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP HEADER: Wallet & High Score
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // High Score Badge
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = AncientStoneSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, AncientStoneBorder)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("🏆", fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "BEST: $highScore",
                            fontWeight = FontWeight.Bold,
                            color = TempleGold,
                            fontSize = 12.sp
                        )
                    }
                }

                // Coins Wallet & Gift Button
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = AncientStoneSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, TempleGold)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("🪙", fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$coins",
                                fontWeight = FontWeight.ExtraBold,
                                color = TempleGold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { preferences.addCoins(300) },
                        modifier = Modifier
                            .size(36.dp)
                            .background(AncientStoneSurface, CircleShape)
                            .testTag("main_menu_gift_btn")
                    ) {
                        Text("🎁", fontSize = 16.sp)
                    }
                }
            }

            // GAME TITLE & HERO PREVIEW
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                Text(
                    text = "TEMPLE RUN",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = TempleGold,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "RELIC ESCAPE",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TempleAmber,
                    letterSpacing = 4.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Hero Preview Showcase Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .height(190.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF1B2820), AncientStoneDark)
                            )
                        )
                        .border(1.dp, AncientStoneBorder, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val fakeState = GameState(
                            distanceMeters = 30f,
                            player = PlayerVisualState(
                                laneX = 0f,
                                jumpY = 0f,
                                isSliding = false,
                                slideProgress = 0f,
                                runStepCycle = runCycle,
                                isInvincible = false,
                                isShielded = false,
                                isMagnetActive = false,
                                isSpeedBoosting = false,
                                isStumbling = false
                            ),
                            equippedCharacter = equippedCharacter,
                            equippedCosmetic = equippedCosmetic
                        )
                        Renderer3D.render(this, fakeState, w, h * 1.05f)
                    }

                    // Hero Name & Customizer Shortcut Tag
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AncientStoneDark.copy(alpha = 0.85f),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 8.dp)
                    ) {
                        Text(
                            text = "${equippedCharacter.name} • ${equippedCosmetic?.name ?: "No Gear"}",
                            color = TextGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // ACTION BUTTONS
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // BIG PLAY BUTTON
                Button(
                    onClick = onStartGame,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TempleGold,
                        contentColor = Color(0xFF241500)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(vertical = 14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("main_play_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "START RUN",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }

                // WARDROBE & UPGRADES ROW
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = onOpenCustomizer,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("main_wardrobe_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = AncientStoneSurface,
                            contentColor = TextGold
                        )
                    ) {
                        Text("👕 WARDROBE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    FilledTonalButton(
                        onClick = onOpenUpgrades,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("main_upgrades_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = AncientStoneSurface,
                            contentColor = TextGold
                        )
                    ) {
                        Text("⚡ SHRINE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                // STATS & SETTINGS TOGGLES ROW
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onOpenStats,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("main_stats_button"),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = TempleAmber
                        )
                    ) {
                        Text("📜 GUIDE & STATS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Controls Toggle
                        FilterChip(
                            selected = arcadeControls,
                            onClick = { preferences.toggleArcadeControls() },
                            label = { Text("Buttons", fontSize = 11.sp) },
                            modifier = Modifier.testTag("toggle_arcade_controls")
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        // Vibration Toggle
                        FilterChip(
                            selected = vibrationEnabled,
                            onClick = { preferences.toggleVibration() },
                            label = { Text("Haptics", fontSize = 11.sp) },
                            modifier = Modifier.testTag("toggle_vibration")
                        )
                    }
                }
            }
        }
    }
}
