package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GamePreferences
import com.example.game.GameState
import com.example.game.PlayerVisualState
import com.example.game.Renderer3D
import com.example.model.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharacterCustomizationScreen(
    preferences: GamePreferences,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coins by preferences.coins.collectAsState()
    val unlockedChars by preferences.unlockedCharacters.collectAsState()
    val equippedCharId by preferences.equippedCharacterId.collectAsState()
    val unlockedCosmetics by preferences.unlockedCosmetics.collectAsState()
    val equippedCosmeticId by preferences.equippedCosmeticId.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0 = Characters, 1 = Cosmetics
    var previewCharId by remember { mutableStateOf(equippedCharId) }
    var previewCosmeticId by remember { mutableStateOf(equippedCosmeticId) }
    var isPreviewRunning by remember { mutableStateOf(true) }
    var runCycle by remember { mutableFloatStateOf(0f) }

    // Run animation for preview podium
    LaunchedEffect(isPreviewRunning) {
        var lastTime = System.nanoTime()
        while (isPreviewRunning) {
            withFrameNanos { now ->
                val dt = ((now - lastTime) / 1_000_000_000f).coerceIn(0f, 0.05f)
                lastTime = now
                runCycle = (runCycle + dt * 2.8f) % 1.0f
            }
        }
    }

    val previewCharacter = CharacterCatalog.getById(previewCharId)
    val previewCosmetic = CosmeticCatalog.getById(previewCosmeticId)

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Temple Wardrobe",
                        fontWeight = FontWeight.Bold,
                        color = TempleGold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("customizer_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TempleGold
                        )
                    }
                },
                actions = {
                    // Coins Wallet Chip
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = AncientStoneSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, TempleGold),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("🪙", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$coins",
                                fontWeight = FontWeight.Bold,
                                color = TempleGold,
                                fontSize = 14.sp
                            )
                        }
                    }

                    // Test Coins / Relic Gift Button
                    IconButton(
                        onClick = { preferences.addCoins(500) },
                        modifier = Modifier.testTag("claim_free_coins_button")
                    ) {
                        Text("🎁", fontSize = 20.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AncientStoneDark
                )
            )
        },
        containerColor = AncientStoneDark
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            // 1. HERO PREVIEW PODIUM
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(AncientStoneDark, AncientStoneMedium, AncientStoneSurface)
                        )
                    )
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                // Podium Canvas
                Canvas(
                    modifier = Modifier.fillMaxSize()
                ) {
                    val w = size.width
                    val h = size.height

                    // Podium base circle
                    drawOval(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFF5D4037), Color(0xFF2C221A), Color.Transparent),
                            center = Offset(w * 0.5f, h * 0.82f),
                            radius = w * 0.38f
                        ),
                        topLeft = Offset(w * 0.2f, h * 0.72f),
                        size = Size(w * 0.6f, h * 0.22f)
                    )

                    // Render Character in perspective using Renderer3D
                    val fakeState = GameState(
                        distanceMeters = 50f,
                        player = PlayerVisualState(
                            laneX = 0f,
                            jumpY = 0f,
                            isSliding = false,
                            slideProgress = 0f,
                            runStepCycle = runCycle,
                            isInvincible = false,
                            isShielded = false,
                            isMagnetActive = false,
                            isSpeedBoosting = false,
                            isStumbling = false
                        ),
                        equippedCharacter = previewCharacter,
                        equippedCosmetic = previewCosmetic
                    )

                    Renderer3D.render(this, fakeState, w, h * 1.08f)
                }

                // Top Hero Info Overlay
                Column(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 12.dp, top = 4.dp)
                ) {
                    Text(
                        text = previewCharacter.name,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        color = TextGold
                    )
                    Text(
                        text = previewCharacter.title,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        color = TempleAmber
                    )
                    if (previewCosmetic != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AncientStoneDark.copy(alpha = 0.85f),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Text(
                                text = "Equipped: ${previewCosmetic.iconSymbol} ${previewCosmetic.name}",
                                fontSize = 11.sp,
                                color = GemCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                // Toggle Preview Animation Button
                IconButton(
                    onClick = { isPreviewRunning = !isPreviewRunning },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .background(AncientStoneDark.copy(alpha = 0.7f), CircleShape)
                ) {
                    Icon(
                        imageVector = if (isPreviewRunning) Icons.Default.PlayArrow else Icons.Default.Star,
                        contentDescription = "Toggle Run",
                        tint = TempleGold
                    )
                }
            }

            // 2. SEGMENTED TABS: HEROES VS COSMETICS
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = AncientStoneMedium,
                contentColor = TempleGold,
                indicator = {}
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            "CHARACTERS (4)",
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == 0) TempleGold else TextMuted
                        )
                    },
                    modifier = Modifier.testTag("tab_characters")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            "COSMETIC GEAR (5)",
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == 1) TempleGold else TextMuted
                        )
                    },
                    modifier = Modifier.testTag("tab_cosmetics")
                )
            }

            // 3. TAB CONTENT
            if (selectedTab == 0) {
                // CHARACTERS LIST
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(CharacterCatalog.ALL_CHARACTERS) { char ->
                        val isUnlocked = unlockedChars.contains(char.id)
                        val isEquipped = equippedCharId == char.id
                        val isSelectedForPreview = previewCharId == char.id

                        CharacterCard(
                            character = char,
                            isUnlocked = isUnlocked,
                            isEquipped = isEquipped,
                            isSelected = isSelectedForPreview,
                            canAfford = coins >= char.unlockCost,
                            onSelectPreview = { previewCharId = char.id },
                            onEquip = {
                                preferences.equipCharacter(char.id)
                                previewCharId = char.id
                            },
                            onUnlock = {
                                if (preferences.spendCoins(char.unlockCost)) {
                                    preferences.unlockCharacter(char.id)
                                    preferences.equipCharacter(char.id)
                                    previewCharId = char.id
                                }
                            }
                        )
                    }
                }
            } else {
                // COSMETICS LIST
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(CosmeticCatalog.ALL_COSMETICS) { cosmetic ->
                        val isUnlocked = unlockedCosmetics.contains(cosmetic.id)
                        val isEquipped = equippedCosmeticId == cosmetic.id
                        val isSelectedForPreview = previewCosmeticId == cosmetic.id

                        CosmeticCard(
                            cosmetic = cosmetic,
                            isUnlocked = isUnlocked,
                            isEquipped = isEquipped,
                            isSelected = isSelectedForPreview,
                            canAfford = coins >= cosmetic.price,
                            onSelectPreview = { previewCosmeticId = cosmetic.id },
                            onEquip = {
                                preferences.equipCosmetic(cosmetic.id)
                                previewCosmeticId = cosmetic.id
                            },
                            onUnequip = {
                                preferences.equipCosmetic(null)
                                previewCosmeticId = null
                            },
                            onUnlock = {
                                if (preferences.spendCoins(cosmetic.price)) {
                                    preferences.unlockCosmetic(cosmetic.id)
                                    preferences.equipCosmetic(cosmetic.id)
                                    previewCosmeticId = cosmetic.id
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CharacterCard(
    character: GameCharacter,
    isUnlocked: Boolean,
    isEquipped: Boolean,
    isSelected: Boolean,
    canAfford: Boolean,
    onSelectPreview: () -> Unit,
    onEquip: () -> Unit,
    onUnlock: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelectPreview() }
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) TempleGold else AncientStoneBorder,
                shape = RoundedCornerShape(12.dp)
            )
            .testTag("char_card_${character.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) AncientStoneSurface else AncientStoneMedium
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Swatch / Avatar representation
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(character.shirtColor)
                        .border(2.dp, character.accentColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (character.isMechanicalOrDemon) "🤖" else "🏃",
                        fontSize = 22.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = character.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextGold
                        )
                        if (isEquipped) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = JungleEmerald.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "EQUIPPED",
                                    color = JungleEmerald,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = character.title,
                        color = TempleAmber,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Action Button
                if (!isUnlocked) {
                    Button(
                        onClick = onUnlock,
                        enabled = canAfford,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TempleGold,
                            contentColor = AncientStoneDark,
                            disabledContainerColor = AncientStoneBorder,
                            disabledContentColor = TextMuted
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("unlock_char_${character.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Unlock",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${character.unlockCost} 🪙",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                } else if (!isEquipped) {
                    FilledTonalButton(
                        onClick = onEquip,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = TempleGoldDark,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("equip_char_${character.id}")
                    ) {
                        Text("EQUIP", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                } else {
                    Surface(
                        shape = CircleShape,
                        color = JungleEmerald,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Equipped",
                                tint = Color.Black,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Bio
            Text(
                text = character.bio,
                color = TextMuted,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Perk Badge
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = AncientStoneDark,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⚡", fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = character.perkName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = TempleGold
                        )
                        Text(
                            text = character.perkDescription,
                            fontSize = 11.sp,
                            color = TextGold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CosmeticCard(
    cosmetic: CosmeticItem,
    isUnlocked: Boolean,
    isEquipped: Boolean,
    isSelected: Boolean,
    canAfford: Boolean,
    onSelectPreview: () -> Unit,
    onEquip: () -> Unit,
    onUnequip: () -> Unit,
    onUnlock: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelectPreview() }
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) GemCyan else AncientStoneBorder,
                shape = RoundedCornerShape(12.dp)
            )
            .testTag("cosmetic_card_${cosmetic.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) AncientStoneSurface else AncientStoneMedium
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Item Icon representation
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(cosmetic.primaryColor.copy(alpha = 0.25f))
                        .border(2.dp, cosmetic.primaryColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = cosmetic.iconSymbol,
                        fontSize = 24.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = cosmetic.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextGold
                        )
                        if (isEquipped) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = GemCyan.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "ACTIVE",
                                    color = GemCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = cosmetic.slot.displayName,
                        color = TempleAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Action Button
                if (!isUnlocked) {
                    Button(
                        onClick = onUnlock,
                        enabled = canAfford,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TempleGold,
                            contentColor = AncientStoneDark,
                            disabledContainerColor = AncientStoneBorder,
                            disabledContentColor = TextMuted
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("unlock_cosmetic_${cosmetic.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingBag,
                            contentDescription = "Buy",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${cosmetic.price} 🪙",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                } else if (!isEquipped) {
                    FilledTonalButton(
                        onClick = onEquip,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = TempleGoldDark,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("equip_cosmetic_${cosmetic.id}")
                    ) {
                        Text("EQUIP", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                } else {
                    OutlinedButton(
                        onClick = onUnequip,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = TextGold
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("unequip_cosmetic_${cosmetic.id}")
                    ) {
                        Text("UNEQUIP", fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = cosmetic.description,
                color = TextMuted,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Visual Effect Callout
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = AncientStoneDark,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("✨", fontSize = 13.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = cosmetic.visualEffect,
                        fontSize = 11.sp,
                        color = GemCyan
                    )
                }
            }
        }
    }
}
