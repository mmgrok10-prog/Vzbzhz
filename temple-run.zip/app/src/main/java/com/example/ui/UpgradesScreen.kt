package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GamePreferences
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpgradesScreen(
    preferences: GamePreferences,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coins by preferences.coins.collectAsState()
    val magnetLvl by preferences.magnetLevel.collectAsState()
    val shieldLvl by preferences.shieldLevel.collectAsState()
    val boostLvl by preferences.boostLevel.collectAsState()
    val multLvl by preferences.multiplierLevel.collectAsState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Temple Shrine Upgrades",
                        fontWeight = FontWeight.Bold,
                        color = TempleGold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("upgrades_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TempleGold
                        )
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = AncientStoneSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, TempleGold),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("🪙", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$coins",
                                fontWeight = FontWeight.Bold,
                                color = TempleGold,
                                fontSize = 14.sp
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AncientStoneDark
                )
            )
        },
        containerColor = AncientStoneDark
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                UpgradeItemCard(
                    title = "Coin Magnet",
                    icon = "🧲",
                    accentColor = MagnetYellow,
                    description = "Pulls all gold coins across all 3 lanes directly to your runner.",
                    currentLevel = magnetLvl,
                    maxLevel = 5,
                    coinsBalance = coins,
                    upgradeCost = (magnetLvl + 1) * 250,
                    onUpgrade = { preferences.upgradeMagnet() },
                    tag = "magnet"
                )
            }

            item {
                UpgradeItemCard(
                    title = "Solar Shield",
                    icon = "🛡️",
                    accentColor = ShieldBlue,
                    description = "Envelops runner in an invincible solar dome, smashing obstacles.",
                    currentLevel = shieldLvl,
                    maxLevel = 5,
                    coinsBalance = coins,
                    upgradeCost = (shieldLvl + 1) * 250,
                    onUpgrade = { preferences.upgradeShield() },
                    tag = "shield"
                )
            }

            item {
                UpgradeItemCard(
                    title = "Relic Rush",
                    icon = "⚡",
                    accentColor = BoostOrange,
                    description = "Rocket forward at blistering speed, invulnerable to all obstacles.",
                    currentLevel = boostLvl,
                    maxLevel = 5,
                    coinsBalance = coins,
                    upgradeCost = (boostLvl + 1) * 250,
                    onUpgrade = { preferences.upgradeBoost() },
                    tag = "boost"
                )
            }

            item {
                UpgradeItemCard(
                    title = "Score Multiplier",
                    icon = "✨",
                    accentColor = DemonPurple,
                    description = "Permanently boosts base score multiplier for all future runs.",
                    currentLevel = multLvl,
                    maxLevel = 5,
                    coinsBalance = coins,
                    upgradeCost = (multLvl + 1) * 300,
                    onUpgrade = { preferences.upgradeMultiplier() },
                    tag = "multiplier"
                )
            }
        }
    }
}

@Composable
private fun UpgradeItemCard(
    title: String,
    icon: String,
    accentColor: Color,
    description: String,
    currentLevel: Int,
    maxLevel: Int,
    coinsBalance: Int,
    upgradeCost: Int,
    onUpgrade: () -> Unit,
    tag: String
) {
    val isMax = currentLevel >= maxLevel
    val canAfford = coinsBalance >= upgradeCost

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AncientStoneBorder, RoundedCornerShape(12.dp))
            .testTag("upgrade_card_$tag"),
        colors = CardDefaults.cardColors(
            containerColor = AncientStoneMedium
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = accentColor.copy(alpha = 0.2f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, accentColor),
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(text = icon, fontSize = 22.sp)
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextGold
                    )
                    // Level stars
                    Row(modifier = Modifier.padding(top = 2.dp)) {
                        for (i in 1..maxLevel) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = if (i <= currentLevel) accentColor else AncientStoneBorder,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                if (isMax) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = JungleEmerald.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "MAX",
                            color = JungleEmerald,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                } else {
                    Button(
                        onClick = onUpgrade,
                        enabled = canAfford,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TempleGold,
                            contentColor = AncientStoneDark,
                            disabledContainerColor = AncientStoneBorder,
                            disabledContentColor = TextMuted
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("upgrade_btn_$tag")
                    ) {
                        Text(
                            text = "$upgradeCost 🪙",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = description,
                fontSize = 12.sp,
                color = TextMuted
            )
        }
    }
}
