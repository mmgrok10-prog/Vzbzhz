package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class GamePreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("temple_runner_prefs", Context.MODE_PRIVATE)

    private val _coins = MutableStateFlow(prefs.getInt(KEY_COINS, 250)) // 250 starter coins!
    val coins: StateFlow<Int> = _coins.asStateFlow()

    private val _highScore = MutableStateFlow(prefs.getInt(KEY_HIGH_SCORE, 0))
    val highScore: StateFlow<Int> = _highScore.asStateFlow()

    private val _unlockedCharacters = MutableStateFlow(
        prefs.getStringSet(KEY_UNLOCKED_CHARACTERS, setOf("harrison")) ?: setOf("harrison")
    )
    val unlockedCharacters: StateFlow<Set<String>> = _unlockedCharacters.asStateFlow()

    private val _equippedCharacterId = MutableStateFlow(
        prefs.getString(KEY_EQUIPPED_CHAR, "harrison") ?: "harrison"
    )
    val equippedCharacterId: StateFlow<String> = _equippedCharacterId.asStateFlow()

    private val _unlockedCosmetics = MutableStateFlow(
        prefs.getStringSet(KEY_UNLOCKED_COSMETICS, emptySet()) ?: emptySet()
    )
    val unlockedCosmetics: StateFlow<Set<String>> = _unlockedCosmetics.asStateFlow()

    private val _equippedCosmeticId = MutableStateFlow(
        prefs.getString(KEY_EQUIPPED_COSMETIC, null)
    )
    val equippedCosmeticId: StateFlow<String?> = _equippedCosmeticId.asStateFlow()

    // Upgrades
    private val _magnetLevel = MutableStateFlow(prefs.getInt(KEY_MAGNET_LVL, 1))
    val magnetLevel: StateFlow<Int> = _magnetLevel.asStateFlow()

    private val _shieldLevel = MutableStateFlow(prefs.getInt(KEY_SHIELD_LVL, 1))
    val shieldLevel: StateFlow<Int> = _shieldLevel.asStateFlow()

    private val _boostLevel = MutableStateFlow(prefs.getInt(KEY_BOOST_LVL, 1))
    val boostLevel: StateFlow<Int> = _boostLevel.asStateFlow()

    private val _multiplierLevel = MutableStateFlow(prefs.getInt(KEY_MULT_LVL, 1))
    val multiplierLevel: StateFlow<Int> = _multiplierLevel.asStateFlow()

    // Settings
    private val _vibrationEnabled = MutableStateFlow(prefs.getBoolean(KEY_VIBRATION, true))
    val vibrationEnabled: StateFlow<Boolean> = _vibrationEnabled.asStateFlow()

    private val _arcadeControlsEnabled = MutableStateFlow(prefs.getBoolean(KEY_ARCADE_CONTROLS, true))
    val arcadeControlsEnabled: StateFlow<Boolean> = _arcadeControlsEnabled.asStateFlow()

    // Lifetime Stats
    private val _totalRuns = MutableStateFlow(prefs.getInt(KEY_TOTAL_RUNS, 0))
    val totalRuns: StateFlow<Int> = _totalRuns.asStateFlow()

    private val _totalDistance = MutableStateFlow(prefs.getFloat(KEY_TOTAL_DISTANCE, 0f))
    val totalDistance: StateFlow<Float> = _totalDistance.asStateFlow()

    fun addCoins(amount: Int) {
        val newBalance = (_coins.value + amount).coerceAtLeast(0)
        _coins.value = newBalance
        prefs.edit().putInt(KEY_COINS, newBalance).apply()
    }

    fun spendCoins(amount: Int): Boolean {
        if (_coins.value >= amount) {
            val newBalance = _coins.value - amount
            _coins.value = newBalance
            prefs.edit().putInt(KEY_COINS, newBalance).apply()
            return true
        }
        return false
    }

    fun saveHighScore(score: Int): Boolean {
        if (score > _highScore.value) {
            _highScore.value = score
            prefs.edit().putInt(KEY_HIGH_SCORE, score).apply()
            return true
        }
        return false
    }

    fun unlockCharacter(id: String): Boolean {
        val updated = _unlockedCharacters.value.toMutableSet().apply { add(id) }
        _unlockedCharacters.value = updated
        prefs.edit().putStringSet(KEY_UNLOCKED_CHARACTERS, updated).apply()
        return true
    }

    fun equipCharacter(id: String) {
        if (_unlockedCharacters.value.contains(id)) {
            _equippedCharacterId.value = id
            prefs.edit().putString(KEY_EQUIPPED_CHAR, id).apply()
        }
    }

    fun unlockCosmetic(id: String): Boolean {
        val updated = _unlockedCosmetics.value.toMutableSet().apply { add(id) }
        _unlockedCosmetics.value = updated
        prefs.edit().putStringSet(KEY_UNLOCKED_COSMETICS, updated).apply()
        return true
    }

    fun equipCosmetic(id: String?) {
        if (id == null || _unlockedCosmetics.value.contains(id)) {
            _equippedCosmeticId.value = id
            prefs.edit().putString(KEY_EQUIPPED_COSMETIC, id).apply()
        }
    }

    fun upgradeMagnet(): Boolean {
        val nextLevel = _magnetLevel.value + 1
        val cost = nextLevel * 250
        if (nextLevel <= 5 && spendCoins(cost)) {
            _magnetLevel.value = nextLevel
            prefs.edit().putInt(KEY_MAGNET_LVL, nextLevel).apply()
            return true
        }
        return false
    }

    fun upgradeShield(): Boolean {
        val nextLevel = _shieldLevel.value + 1
        val cost = nextLevel * 250
        if (nextLevel <= 5 && spendCoins(cost)) {
            _shieldLevel.value = nextLevel
            prefs.edit().putInt(KEY_SHIELD_LVL, nextLevel).apply()
            return true
        }
        return false
    }

    fun upgradeBoost(): Boolean {
        val nextLevel = _boostLevel.value + 1
        val cost = nextLevel * 250
        if (nextLevel <= 5 && spendCoins(cost)) {
            _boostLevel.value = nextLevel
            prefs.edit().putInt(KEY_BOOST_LVL, nextLevel).apply()
            return true
        }
        return false
    }

    fun upgradeMultiplier(): Boolean {
        val nextLevel = _multiplierLevel.value + 1
        val cost = nextLevel * 300
        if (nextLevel <= 5 && spendCoins(cost)) {
            _multiplierLevel.value = nextLevel
            prefs.edit().putInt(KEY_MULT_LVL, nextLevel).apply()
            return true
        }
        return false
    }

    fun toggleVibration() {
        val next = !_vibrationEnabled.value
        _vibrationEnabled.value = next
        prefs.edit().putBoolean(KEY_VIBRATION, next).apply()
    }

    fun toggleArcadeControls() {
        val next = !_arcadeControlsEnabled.value
        _arcadeControlsEnabled.value = next
        prefs.edit().putBoolean(KEY_ARCADE_CONTROLS, next).apply()
    }

    fun recordRunCompleted(distance: Float, coins: Int) {
        val runs = _totalRuns.value + 1
        val dist = _totalDistance.value + distance
        _totalRuns.value = runs
        _totalDistance.value = dist
        prefs.edit()
            .putInt(KEY_TOTAL_RUNS, runs)
            .putFloat(KEY_TOTAL_DISTANCE, dist)
            .apply()
    }

    companion object {
        private const val KEY_COINS = "coins_balance"
        private const val KEY_HIGH_SCORE = "high_score"
        private const val KEY_UNLOCKED_CHARACTERS = "unlocked_chars"
        private const val KEY_EQUIPPED_CHAR = "equipped_char"
        private const val KEY_UNLOCKED_COSMETICS = "unlocked_cosmetics"
        private const val KEY_EQUIPPED_COSMETIC = "equipped_cosmetic"
        private const val KEY_MAGNET_LVL = "magnet_level"
        private const val KEY_SHIELD_LVL = "shield_level"
        private const val KEY_BOOST_LVL = "boost_level"
        private const val KEY_MULT_LVL = "mult_level"
        private const val KEY_VIBRATION = "vibration_enabled"
        private const val KEY_ARCADE_CONTROLS = "arcade_controls"
        private const val KEY_TOTAL_RUNS = "total_runs"
        private const val KEY_TOTAL_DISTANCE = "total_distance"
    }
}
