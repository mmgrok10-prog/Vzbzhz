package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.GamePreferences
import com.example.game.GameEngine
import com.example.game.GameStatus
import com.example.model.CharacterCatalog
import com.example.model.CosmeticCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Temple Run", appName)
    }

    @Test
    fun `test character catalog has base and 3 unlockables`() {
        val allChars = CharacterCatalog.ALL_CHARACTERS
        assertEquals(4, allChars.size)

        val base = CharacterCatalog.BASE_CHARACTER
        assertEquals("harrison", base.id)
        assertEquals(0, base.unlockCost)

        val maya = CharacterCatalog.UNLOCKABLE_1
        assertEquals("maya", maya.id)
        assertEquals(500, maya.unlockCost)

        val kage = CharacterCatalog.UNLOCKABLE_2
        assertEquals("kage", kage.id)
        assertEquals(1200, kage.unlockCost)

        val solaris = CharacterCatalog.UNLOCKABLE_3
        assertEquals("solaris", solaris.id)
        assertEquals(2500, solaris.unlockCost)
    }

    @Test
    fun `test cosmetic catalog contains 5 items`() {
        val cosmetics = CosmeticCatalog.ALL_COSMETICS
        assertEquals(5, cosmetics.size)
        assertTrue(cosmetics.any { it.id == "sun_crown" })
        assertTrue(cosmetics.any { it.id == "aviator_scarf" })
        assertTrue(cosmetics.any { it.id == "oni_mask" })
        assertTrue(cosmetics.any { it.id == "royal_cape" })
        assertTrue(cosmetics.any { it.id == "cyber_visor" })
    }

    @Test
    fun `test character unlocking and equipping in preferences`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val preferences = GamePreferences(context)

        // Harrison is unlocked by default
        assertTrue(preferences.unlockedCharacters.value.contains("harrison"))
        assertEquals("harrison", preferences.equippedCharacterId.value)

        // Add coins and unlock Maya
        preferences.addCoins(1000)
        val spent = preferences.spendCoins(500)
        assertTrue(spent)

        preferences.unlockCharacter("maya")
        assertTrue(preferences.unlockedCharacters.value.contains("maya"))

        preferences.equipCharacter("maya")
        assertEquals("maya", preferences.equippedCharacterId.value)
    }

    @Test
    fun `test cosmetic unlocking and equipping in preferences`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val preferences = GamePreferences(context)

        preferences.addCoins(1500)
        assertTrue(preferences.spendCoins(300))

        preferences.unlockCosmetic("sun_crown")
        assertTrue(preferences.unlockedCosmetics.value.contains("sun_crown"))

        preferences.equipCosmetic("sun_crown")
        assertEquals("sun_crown", preferences.equippedCosmeticId.value)

        preferences.equipCosmetic(null)
        assertEquals(null, preferences.equippedCosmeticId.value)
    }

    @Test
    fun `test swipe-to-dodge mechanics left right jump slide in game engine`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val preferences = GamePreferences(context)
        val engine = GameEngine(preferences)

        engine.startNewGame()
        assertEquals(GameStatus.RUNNING, engine.gameState.value.status)
        assertEquals(0f, engine.gameState.value.player.laneX, 0.01f)

        // Dodge left
        engine.moveLeft()
        // Simulate a few physics update frames
        for (i in 0..10) {
            engine.update(0.016f)
        }
        // Lane position should shift towards -1.0f and banking tilt should be negative
        assertTrue("Player should move left", engine.gameState.value.player.laneX < -0.3f)
        assertTrue("Character should tilt during left dodge", engine.gameState.value.player.tiltAngle < 0f)

        // Dodge right back to center and towards right
        engine.moveRight()
        engine.moveRight()
        for (i in 0..10) {
            engine.update(0.016f)
        }
        assertTrue("Player should move right", engine.gameState.value.player.laneX > -0.5f)
        assertTrue("Character should tilt during right dodge", engine.gameState.value.player.tiltAngle > 0f)

        // Jump test
        engine.jump()
        engine.update(0.016f)
        assertTrue("Player should be in midair after jump", engine.gameState.value.player.jumpY > 0.1f)

        // Slide mid-air test (dive-down slam)
        engine.slide()
        engine.update(0.016f)
        assertTrue("Player should be in sliding state", engine.gameState.value.player.isSliding)

        // Settle back to ground
        for (i in 0..30) {
            engine.update(0.016f)
        }
        assertEquals(0f, engine.gameState.value.player.jumpY, 0.05f)
    }
}
